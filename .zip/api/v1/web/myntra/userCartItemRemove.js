// routes/api/v1/myntra.js
const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { userCartItemRemove } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/userCartItemRemove:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Retrieve usercartitemadd item details.
 *   description: API used for retrieving usercartitemadd item details.
 *   parameters:
 *      - in: body
 *        name: cartItems
 *        description: usercartitemadd items to fetch details for.
 *        schema:
 *         type: object
 *         properties:
 *           cartid:
 *             type: string
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */

const dataSchema = Joi.object({
  cartid: Joi.string().required().label("cartid")
});

router.post(
  "/userCartItemRemove",
  commonResolver.bind({
    modelService: userCartItemRemove,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);

module.exports = router;
