const express = require("express");
const { Joi } = require("../../../../utilities/schemaValidate");
const commonResolver = require("../../../../utilities/commonResolver");
const { AddCatalog } = require("../../../../services/myntra/myntra");
const router = express.Router();

/**
 * @swagger
 * /api/v1/Myntra/AddCatalog:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Save AddCatalog information.
 *   description: API used for saving AddCatalog information.
 *   parameters:
 *      - in: body
 *        name: catalog
 *        description: Save AddCatalog information.
 *        schema:
 *         type: object
 *         properties:
 *           token:
 *             type: string
 *           category:
 *             type: string
 *           subcategory:
 *             type: string
 *           subcategoryitem:
 *             type: string
 *           productName:
 *             type: string
 *           ShortDescription:
 *             type: string
 *           productPrice:
 *             type: string
 *           productMrp:
 *             type: string
 *           color:
 *             type: array
 *             items:
 *               type: object
 *               properties:
 *                 color:
 *                   type: string
 *                 images:
 *                   type: array
 *                   items:
 *                     type: string
 *                 sizes:
 *                   type: array
 *                   items:
 *                     type: string
 *           Fabric:
 *             type: string
 *           sleeveStyling:
 *             type: string
 *           sleeveLength:
 *             type: string
 *           fitShape:
 *             type: string
 *           Neck:
 *             type: string
 *           occasion:
 *             type: string
 *           pattern:
 *             type: string
 *           printOrpattern:
 *             type: string
 *           Description:
 *             type: string
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */

const dataSchema = Joi.object({
    token:Joi.string().required(),
    category: Joi.string().required(),
    subcategory: Joi.string().required(),
    subcategoryitem: Joi.string().required(),
    productName: Joi.string().required(),
    ShortDescription: Joi.string().required(),
    productPrice: Joi.string().required(),
    productMrp: Joi.string().required(),
    color: Joi.array().items(Joi.object({
        color: Joi.string().required(),
        images: Joi.array().items(Joi.string().required()).required(),
        sizes: Joi.array().items(Joi.string().required()).required()
    })).required(),
    Fabric: Joi.string().required(),
    sleeveStyling: Joi.string().required(),
    sleeveLength: Joi.string().required(),
    fitShape: Joi.string().required(),
    Neck: Joi.string().required(),
    occasion: Joi.string().required(),
    pattern: Joi.string().required(),
    printOrpattern: Joi.string().required(),
    Description: Joi.string().required()
});

router.post(
  "/AddCatalog",
  commonResolver.bind({
    modelService: AddCatalog,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);

module.exports = router;
