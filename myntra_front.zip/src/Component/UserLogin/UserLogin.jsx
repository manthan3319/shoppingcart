import React, { useEffect, useState } from 'react';
import { Navbar } from '../Navbar/Navbar';
import "../component.css";
import { loginbanner } from '../../Images/Images';
import { sendOtpAPI } from '../../Api/Api';
import { useNavigate } from 'react-router-dom';
import { createDebouncedFunction } from '../../Function/Function';

export const UserLogin = () => {
    const [userEmail, setuserEmail] = useState("");
    const navigate = useNavigate(); 
    const userToken = sessionStorage.getItem('userToken');

    useEffect(() => {
        if (userToken) {
            navigate('/');
        }
    }, [userToken, navigate]);

    const userlogin = async (e) => {
        e.preventDefault();
        try {
            const response = await sendOtpAPI({ email: userEmail });
            if (response.data.statusCode === 200) {
                sessionStorage.setItem('userEmail', userEmail);
                navigate('/userotpverify');
            } else {
                console.error('Failed to send OTP. Status code:', response.statusCode);
            }
        } catch (error) {
            console.error('Error sending OTP:', error);
        }
    };

    const userloginFn = createDebouncedFunction(userlogin, 300);


    return (
        <div className='bg-[#0be34d21] min-h-[100vh]'>
            <Navbar />
            <div className='lg:max-w-[1000px] mx-auto m-0 px-[50px] mt-[20px]'>
                <div className='userLogin_section'>
                    <div className='w-[40%] bg-white rounded-b-[5px]'>
                        <div>
                            <img src={loginbanner} alt='Login Banner' className='' />
                        </div>
                        <div className='p-[30px]'>
                            <h1 className='text-pop font-roboto font-bold text-[18px]'>Login <span className='font-normal'>Or</span> Signup</h1>
                            <div className='my-[15px]'>
                                <input
                                    type='email'
                                    placeholder='Enter Email'
                                    value={userEmail}
                                    onChange={(e) => setuserEmail(e.target.value)}
                                    className='border-[1px] outline-none font-roboto text-[14px] p-[7px] w-[100%] rounded-[4px]'
                                />
                            </div>
                            <button
                                className='bg-bgmesho w-[100%] text-white py-[10px] text-[15px]'
                                onClick={userloginFn}
                            >
                                CONTINUE
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
