import React from 'react';
import { Navbar } from '../Navbar/Navbar';
import { ProductCard } from '../../Function/Function';
import { fetchProductDataAPI } from '../../Api/Api';
import { NavbarMenu } from '../../Content/Content';
import { useParams, Navigate, Link } from 'react-router-dom';


export const Product = () => {
  const { category, subcategory, item } = useParams();

  const [productData, setProductData] = React.useState(null);
  const validateParams = () => {
    const categoryObj = NavbarMenu.find(cat => cat.title.toLowerCase() === category.toLowerCase());
    if (!categoryObj) return false;

    if (subcategory) {
      const subcategoryObj = categoryObj.subcategories?.find(sub => sub.title.toLowerCase() === subcategory.toLowerCase());
      if (!subcategoryObj) return false;

      if (item) {
        const itemObj = subcategoryObj.iteam?.find(it => it.toLowerCase() === item.toLowerCase());
        if (!itemObj) return false;
      }
    }

    return true;
  };
  React.useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await fetchProductDataAPI(category, subcategory, item);
        setProductData(data);
      } catch (error) {
        console.error('Error fetching product data:', error);
      }
    };

    fetchData();
  }, [category, subcategory, item]);

  var settings = {
    dots: false,
    infinite: true,
    speed: 2000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 5000
  };

  return (
    <div>
      <Navbar />
      <div className='lg:max-w-[1440px] mx-auto m-0 px-[50px] mt-[20px]'>
        <div className='flex flex-wrap gap-[36px]'>
          {productData !== null && productData.map((product, index) => (
              <ProductCard key={index} product={product} settings={settings} />
          ))}
        </div>
      </div>
    </div>
  );
};


