import React, { useState, useEffect } from 'react';
import { logo2 } from '../../../Images/Images';
import { config } from '../../../config';
import { useNavigate } from 'react-router-dom';
import '../../mainadmin.css';

export const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [rememberMe, setRememberMe] = useState(false);

  const Owntoken = sessionStorage.getItem('owner');

  useEffect(() => {
    if (Owntoken) {
      navigate('/ownerPanel');
    }
  }, [Owntoken]);

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(`${config.apiBaseUrl}/api/v1/Myntra/LoginMainAdmin`, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const result = await response.json();

      if (response.status === 200) {
        const errorMessage = result.data.message;

        if (errorMessage === "Password is incorrect!" || errorMessage === "Your Email is incorrect!") {
          setError(errorMessage);
        } else {
          setError('');
          if (rememberMe) {
            localStorage.setItem('email', email);
            localStorage.setItem('password', password);
          } else {
            localStorage.removeItem('email');
            localStorage.removeItem('password');
          }
          const token = result.data.token;
          sessionStorage.setItem('owner', token);
          navigate("/ownerPanel")
        }
      } else {
        setError('An error occurred!');
      }
    } catch (error) {
      setError('An error occurred!');
      console.error('Login error:', error);
    }
  };

 
  return (
    <div className='login_bg'>
    <div className='lg:max-w-[1440px] mx-auto m-0 px-[50px] '>
      <div className='login_panel'>
        <div className='login_main'>
          <div>
            <img src={logo2} alt='logo' className='logologin' />
          </div>

          <form onSubmit={handleLogin} className='mt-[20px] flex flex-col gap-y-[10px]'>
            <h1 className='font-roboto text-[16px] font-bold'>Login Owner</h1>
            <div className='mt-[10px] flex flex-col gap-y-[8px]'>
              <fieldset className={`border-gray-400 border-[1px] py-[4px] px-[10px] rounded-[5px] ${error ? 'border-red-500' : ''}`}>
                <legend className='text-[12px] font-roboto'>Email:</legend>
                <input type='email' name="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder='Enter Owner email' className='w-[100%] outline-none font-roboto text-[13px]' />
              </fieldset>

              <fieldset className={`border-gray-400 border-[1px] py-[4px] px-[10px] mt-[10px] rounded-[5px] ${error ? 'border-red-500' : ''}`}>
                <legend className='text-[12px] font-roboto'>Password:</legend>
                <input type='password' name="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder='Password' className='w-[100%] outline-none font-roboto text-[13px]' />
              </fieldset>
            </div>

            <div className='mt-[10px] flex items-center'>
              <input type='checkbox' checked={rememberMe} onChange={(e) => setRememberMe(e.target.checked)} />
              <label className='ml-[5px] font-roboto text-[12px]'>Remember me</label>
            </div>

            <div>
              <button type='submit' className='login_owner_btn'>Log in</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    </div>
  );
};
