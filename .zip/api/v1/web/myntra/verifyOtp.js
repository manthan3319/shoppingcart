/**
 * This is Contain Save router/api.
 * @author manthan Vaghasiya
 *
 */

const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { verifyOtp } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/verifyOtp:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Save verifyOtp information.
 *   description: api used for Save verifyOtp information.
 *   parameters:
 *      - in: body
 *        name: lead
 *        description: Save verifyOtp information.
 *        schema:
 *         type: object
 *         properties:
 *           otp:
 *             type: number
 *           email:
 *             type: string
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */

const dataSchema = Joi.object({
  otp: Joi.number().required().label("otp"),
  email: Joi.string().required().label("email"),
});

router.post(
  "/verifyOtp",
  commonResolver.bind({
    modelService: verifyOtp,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);

module.exports = router;
