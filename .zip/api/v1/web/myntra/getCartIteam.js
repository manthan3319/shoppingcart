// routes/api/v1/myntra.js
const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { getCartIteam } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/getCartIteam:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Retrieve cart item details.
 *   description: API used for retrieving cart item details.
 *   parameters:
 *      - in: body
 *        name: cartItems
 *        description: Cart items to fetch details for.
 *        schema:
 *         type: object
 *         properties:
 *           token:
 *             type: string
 *           cartItems:
 *             type: array
 *             items:
 *               type: object
 *               properties:
 *                 productId:
 *                   type: string
 *                 size:
 *                   type: string
 *                 color:
 *                   type: number
 *                 qty:
 *                   type: number
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */



router.post(
  "/getCartIteam",
  commonResolver.bind({
    modelService: getCartIteam,
  })
);

module.exports = router;
