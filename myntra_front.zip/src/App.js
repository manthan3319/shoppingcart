import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Dashboard } from './Component/Dashboard/Dashboard';
import { Product } from './Component/Product/Product';
import { Login } from './MainAdmin/components/Login/Login';
import { OwnerPanel } from './MainAdmin/components/OwnerPanel/OwnerPanel';
import { NotFound } from './Component/Notfound/NotFound ';
import { Productview } from './Component/Productview/Productview';
import { AddToCart } from './Component/AddToCart/AddToCart';
import { UserLogin } from './Component/UserLogin/UserLogin';
import { LoginOtp } from './Component/LoginOtp/LoginOtp';

export const App = () => {

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<Dashboard />} />
      <Route path="/:category" element={<Product />} />
      <Route path="/:category/:subcategory" element={<Product />} />
      <Route path="/:category/:subcategory/:item" element={<Product />} />
      <Route path="/productview" element={<Productview/>} />
      <Route path="/bag" element={<AddToCart/>} />
      <Route path="/userlogin" element={<UserLogin/>} />
      <Route path="/userotpverify" element={<LoginOtp/>} />


      <Route path="/owner" element={<Login />} />
      <Route path="/ownerPanel" element={<OwnerPanel />} />
      {/* 404 Route */}
      <Route path="/404" element={<NotFound />} />
    </Routes>
  );
};
