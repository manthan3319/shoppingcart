// routes/api/v1/myntra.js
const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { adduseradress } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/adduseradress:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Retrieve adduseradress item details.
 *   description: API used for retrieving adduseradress item details.
 *   parameters:
 *      - in: body
 *        name: cartItems
 *        description: adduseradress items to fetch details for.
 *        schema:
 *         type: object
 *         properties:
 *           usertoken:
 *             type: string
 *           name:
 *             type: string
 *           number:
 *             type: number
 *           pincode:
 *             type: number
 *           address:
 *             type: string
 *           locality:
 *             type: string
 *           state:
 *             type: string
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */ 

const dataSchema = Joi.object({
  usertoken: Joi.string().required().label("usertoken"),
  name: Joi.string().required().label("name"),
  number: Joi.number().required("number"),
  pincode: Joi.number().required("pincode"),
  address: Joi.string().required("address"),
  locality: Joi.string().required("locality"),
  state: Joi.string().required("state"),
});

router.post(
  "/adduseradress",
  commonResolver.bind({
    modelService: adduseradress,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);

module.exports = router;
