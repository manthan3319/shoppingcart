/**
 * This is Contain Save router/api.
 * @author manthan Vaghasiya
 *
 */

const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { AddBrand } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/AddBrand:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Save AddBrand information.
 *   description: api used for saving AddBrand information.
 *   parameters:
 *      - in: body
 *        name: lead
 *        description: Save AddBrand information.
 *        schema:
 *         type: object
 *         properties:
 *           brand:
 *             type: array
 *             items:
 *               type: string
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */

const dataSchema = Joi.object({
  brand: Joi.array().items(Joi.string().required()).required().label("brand"),
});

router.post(
  "/AddBrand",
  commonResolver.bind({
    modelService: AddBrand,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);

module.exports = router;
