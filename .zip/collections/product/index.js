const mongoose = require("mongoose");

const catalogSchema = new mongoose.Schema({
  supplierId: { type: String, required: true },
  category: { type: String, required: true },
  subcategory: { type: String, required: true },
  subcategoryitem: { type: String, required: true },
  productName: { type: String, required: true },
  ShortDescription: { type: String, required: true },
  productPrice: { type: Number, required: true },
  productMrp: { type: Number, required: true },
  color: [{
    color: { type: String, required: true },
    images: [{ type: String, required: true }],
    sizes: [{ type: String, required: true }]
  }],
  Fabric: { type: String, required: true },
  sleeveStyling: { type: String, required: true },
  sleeveLength: { type: String, required: true },
  fitShape: { type: String, required: true },
  Neck: { type: String, required: true },
  occasion: { type: String, required: true },
  pattern: { type: String, required: true },
  printOrpattern: { type: String, required: true },
  Description: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date }
});

module.exports = mongoose.model("Product", catalogSchema);
