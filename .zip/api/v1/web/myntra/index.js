/*
 * @file: index.js
 * @description: It's combine all contractor routers.
 * @author: manthan Vaghasiya
 */

const AddNewMainAdmin = require("./AddNewMainAdmin");
const LoginMainAdmin = require("./LoginMainAdmin");
const AddCategory = require("./AddCategory");
const getCategory =  require("./getCategory");
const AddSubCategory = require("./AddSubCategory");
const getSubCategory = require("./getSubCategory");
const AddSubCategoryItem = require("./AddSubCategoryItem");
const AddBrand = require("./AddBrand");
const getIteamwithCategory = require("./getIteamwithCategory");
const UploadImages = require("./UploadImages");
const AddCatalog = require("./AddCatalog");
const getIteamwithCondition = require("./getIteamwithCondition");
const getCartIteam = require("./getCartIteam");
const sendOtp = require("./sendOtp");
const verifyOtp =  require("./verifyOtp");
const usercartitemadd =  require("./usercartitemadd");
const userCartItemRemove = require("./userCartItemRemove");
const photodetected = require("./photodetected");
const updateCartItemQty = require("./updateCartItemQty");
const adduseradress = require("./adduseradress");

module.exports = [
    AddNewMainAdmin,
    LoginMainAdmin,
    AddCategory,
    getCategory,
    AddSubCategory,
    getSubCategory,
    AddSubCategoryItem,
    AddBrand,
    getIteamwithCategory,
    UploadImages,
    AddCatalog,
    getIteamwithCondition,
    getCartIteam,
    sendOtp,
    verifyOtp,
    usercartitemadd,
    userCartItemRemove,
    photodetected,
    updateCartItemQty,
    adduseradress
];
