import React, { useEffect, useState } from 'react';
import { Navbar } from '../Navbar/Navbar';
import { mobileverifyimg } from '../../Images/Images';
import OTPInput from "otp-input-react";
import { useNavigate } from 'react-router-dom';
import { OtpverfiyAPI, usercartitemAddAPI } from '../../Api/Api';

export const LoginOtp = () => {
    const [OTP, setOTP] = useState("");
    const [error, setError] = useState("");
    const navigate = useNavigate();
    const inputStyles = {
        width: '40px',
        height: '50px',
        margin: '5px',
        fontSize: '20px',
        border: '1px solid #ccc',
        borderRadius: '5px',
        textAlign: 'center',
    };
    const CartItems = JSON.parse(localStorage.getItem('cart')) || [];
    const userEmail = sessionStorage.getItem('userEmail');

    const verifyOtp = async () => {
        try {
            const response = await OtpverfiyAPI(userEmail, OTP);
            if (response.data.message === "Login successful!") {
                sessionStorage.setItem('userToken', response.data.token);
                sessionStorage.removeItem('userEmail');

                const userToken = sessionStorage.getItem('userToken');
                if (userToken) {
                    try {
                        const responseCartItemAdd = await usercartitemAddAPI(userToken, CartItems);
                        console.log("responseCartItemAdd.statusCode",responseCartItemAdd.statusCode);
                        if(responseCartItemAdd.statusCode === 200){
                            localStorage.removeItem('cart');
                        }
                    } catch (error) {
                        console.error('No cart data found or empty response');
                    }
                }
                navigate('/');
            } else {
                setError('Failed to verify OTP. Please try again.');
            }
        } catch (error) {
            console.error('Error verifying OTP:', error);
            setError('An error occurred during OTP verification. Please try again.');
        }
    };

    useEffect(() => {
        if (userEmail === null) {
            navigate('/userlogin');
        }
    }, [userEmail, navigate]);

    useEffect(() => {
        if (OTP.length === 6) {
            verifyOtp();
        }
    }, [OTP]);

    return (
        <div className='bg-[#0be34d21] min-h-[100vh]'>
            <Navbar />
            <div className='lg:max-w-[1000px] mx-auto m-0 px-[50px] mt-[20px] flex items-center h-[72vh]'>
                <div className='userLogin_section'>
                    <div className='w-[40%] bg-white rounded-[7px]'>
                        <div>
                            <img src={mobileverifyimg} alt='otp verify' className='w-[130px]' />
                        </div>
                        <div className='p-[20px]'>
                            <h1 className='text-pop text-[15px] font-roboto '>Verify with OTP</h1>
                            <p className='mb-[10px] text-[12px] font-roboto'>Sent to <b>{userEmail}</b></p>
                            <OTPInput
                                value={OTP}
                                onChange={setOTP}
                                autoFocus
                                OTPLength={6}
                                otpType="number"
                                disabled={false}
                                inputStyles={inputStyles}
                                style={{ justifyContent: 'center' }}
                            />
                            {error && <p className='text-red-500 text-[12px]'>{error}</p>}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
