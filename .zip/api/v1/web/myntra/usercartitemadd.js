// routes/api/v1/myntra.js
const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { usercartitemadd } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/usercartitemadd:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Retrieve usercartitemadd item details.
 *   description: API used for retrieving usercartitemadd item details.
 *   parameters:
 *      - in: body
 *        name: cartItems
 *        description: usercartitemadd items to fetch details for.
 *        schema:
 *         type: object
 *         properties:
 *           token:
 *             type: string
 *           cartItems:
 *             type: array
 *             items:
 *               type: object
 *               properties:
 *                 productId:
 *                   type: string
 *                 size:
 *                   type: string
 *                 color:
 *                   type: number
 *                 qty:
 *                   type: number
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */ 

const dataSchema = Joi.object({
token: Joi.string().required().label("token"),
  cartItems: Joi.array().items(
    Joi.object({
      productId: Joi.string().required(),
      size: Joi.string().required(),
      color: Joi.number().required(),
      qty: Joi.number().required(),
    })
  ).required().label("cartItems"),
});

router.post(
  "/usercartitemadd",
  commonResolver.bind({
    modelService: usercartitemadd,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);

module.exports = router;
