import React from 'react';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { Link } from 'react-router-dom';
import {
    category1,
    category2,
    category3,
    category4,
    category5,
    category6,
    category7,
    category8
} from '../../Images/Images';

export const CrazyDeals = () => {
    const categories = [
        { id: 1, img: category1, link: '/category1' },
        { id: 2, img: category2, link: '/category2' },
        { id: 3, img: category3, link: '/category3' },
        { id: 4, img: category4, link: '/category4' },
        { id: 5, img: category5, link: '/category5' },
        { id: 6, img: category6, link: '/category6' },
        { id: 7, img: category7, link: '/category7' },
        { id: 8, img: category8, link: '/category8' },
    ];

    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 4,
    };

    return (
        <div className='mt-[30px]'>
            <div>
                <Slider {...settings}>
                    {categories.map(category => (
                        <div key={category.id}>
                            <Link to={category.link}><img src={category.img} alt='category' /></Link>
                        </div>
                    ))}
                </Slider>
            </div>
        </div>
    );
};
