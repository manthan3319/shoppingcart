import React from 'react'
import { Navbar } from '../Navbar/Navbar'
import { LandingBanner } from '../LandingBanner/LandingBanner'

export const Dashboard = () => {
  return (
    <>
        <Navbar/>
        <LandingBanner/>
    </>
  )
}
