import React from 'react';
import { FooterMenu, POPULARSEARCHES } from '../../Content/Content';
import {
  google_play,
  apple_store,
  fb,
  twitter,
  yt,
  insta,
  original,
  returns
} from '../../Images/Images';
import { Link } from 'react-router-dom';
export const Footer = () => {
  return (
    <div className='lg:max-w-[1440px] mx-auto m-0 px-[50px] bg-[#FAFBFC] mt-[70px] pt-[40px] border-t-[1px] border-gray-400 pb-[50px]'>
      <div className='flex'>
        <div className='flex flex-wrap w-[30%]'>
          {FooterMenu.map((menu, index) => (
            <div key={index} className='w-[50%]'>
              <h1 className='font-roboto text-[12px] font-semibold mb-[19px]'>{menu.title}</h1>
              <ul>
                {menu.iteam.map((item, itemIndex) => (
                  <li key={itemIndex} className='font-roboto text-[13px] text-[gray] pb-[5px] hover:text-black'>{item}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className='w-[40%]'>
          <h1 className='font-roboto text-[12px] font-semibold mb-[19px]'>EXPERIENCE MYNTRA APP ON MOBILE</h1>
          <div className='flex items-center gap-[5px]'>
            <div>
              <Link><img src={google_play} alt='google play' className='w-[190px]' /></Link>
            </div>
            <div>
              <Link><img src={apple_store} alt='apple store' className='w-[190px]' /></Link>
            </div>
          </div>

          <div className='mt-[20px]'>
            <h2 className='font-roboto text-[11px] font-semibold mb-[19px]'>KEEP IN TOUCH</h2>
            <div className='flex gap-[10px] items-center'>
              <Link><img src={fb} alt='fb' className='w-[20px]' /></Link>
              <Link><img src={twitter} alt='twitter' className='w-[20px]' /></Link>
              <Link><img src={yt} alt='yt' className='w-[20px]' /></Link>
              <Link><img src={insta} alt='insta' className='w-[20px]' /></Link>
            </div>
          </div>
        </div>

        <div className='w-[30%]'>
          <div className='flex gap-[10px] items-center'>
            <div>
              <img src={original} alt='original' className='w-[70px]' />
            </div>
            <div>
              <p className='text-[16px] font-roboto'><b>100% ORIGINAL </b>guarantee for <br></br>all products at myntra.com</p>
            </div>
          </div>

          <div className='flex gap-[10px] items-center mt-[20px]'>
            <div>
              <img src={returns} alt='original' className='w-[70px]' />
            </div>
            <div>
              <p className='text-[16px] font-roboto'><b>Return within 14days</b>of <br></br> receiving your order</p>
            </div>
          </div>
        </div>
      </div>

      <div className='popular-searches mt-[20px]'>
        <h2 className='search-list font-roboto text-[14px] font-semibold mb-[19px]'>Popular Searches</h2>
        <ul className=' flex flex-wrap '>
          {POPULARSEARCHES.map((search, index) => (
            <li key={index} className='search-item font-roboto text-[gray] text-[14px] pr-[15px]'> <Link>{search}</Link></li>
          ))}
        </ul>
      </div>
    </div>
  );
};
