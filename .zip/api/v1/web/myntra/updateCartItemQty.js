/**
 * This is Contain Save router/api.
 * @author manthan Vaghasiya
 *
 */

const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { updateCartItemQty } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/updateCartItemQty:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Save updateCartItemQty information.
 *   description: api used for Save updateCartItemQty information.
 *   parameters:
 *      - in: body
 *        name: lead
 *        description: Save updateCartItemQty information.
 *        schema:
 *         type: object
 *         properties:
 *           productId:
 *             type: string
 *           token:
 *             type: string
 *           size:
 *             type: string
 *           qty:
 *             type: number
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */

const dataSchema = Joi.object({
  productId: Joi.string().required().label("productId"),
  token: Joi.string().required().label("token"),
  size: Joi.string().required().label("size"),
  qty: Joi.number().required().label("qty"),
});

router.post(
  "/updateCartItemQty",
  commonResolver.bind({
    modelService: updateCartItemQty,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);

module.exports = router;
