import React from 'react';
import {
    ShopByCategory,
    category9,
    category10,
    category11,
    category12,
    category13,
    category14,
    category15,
    category16,
    category17,
    category18,
    category19,
    category20,
    category21,
} from '../../Images/Images';
import { Link } from 'react-router-dom';

const categories = [
    category9, category10, category11, category12, category13,
    category14, category15, category16, category17, category18,
    category19, category20, category21,
];

export const ShopCategory = () => {
    return (
        <div className='mt-[50px]'>
            <div>
                <img src={ShopByCategory} alt='shop_by_category' />
            </div>

            <div className='flex flex-wrap mt-[10px] justify-center'>
                {categories.map((category, index) => (
                    <Link key={index}>
                        <img src={category} alt={`category-${index}`} className='w-[190px]' />
                    </Link>
                ))}
            </div>
        </div>
    );
}
