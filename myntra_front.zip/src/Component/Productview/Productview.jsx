import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Navbar } from "../Navbar/Navbar";
import { AddCartItemAPI, fetchProductDataAPI, GetCartItemAPI } from "../../Api/Api";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { ProductDetailSection } from "../../Function/Function";
import { ProductSizeData } from "../../Content/Content";
import { ToastContainer, toast } from "react-toastify";

export const Productview = () => {
  const [product, setProduct] = useState(null);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const productId = searchParams.get("id");
  const [selectedSize, setSelectedSize] = useState(null);
  const [cartbtnindex, setcartbtnindex] = useState(0);
  const token = sessionStorage.getItem("userToken");

  useEffect(() => {
    const fetchProductDetails = async () => {
      try {
        const data = await fetchProductDataAPI(null, null, null, productId);
        if (data && data.length > 0) {
          setProduct(data[0]);
        } else {
          console.error("Product not found");
        }
      } catch (error) {
        console.error("Error fetching product details:", error);
      }
    };

    fetchProductDetails();
  }, [productId]);

  useEffect(() => {
    SelectedSize();
  }, [selectedSize]);

  const sliderSettings = {
    dots: true,
    arrows: false,
    infinite: true,
    speed: 1000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
  };

  const sizeOrderMap = ProductSizeData.reduce((map, size, index) => {
    map[size.value] = index;
    return map;
  }, {});

  let sortedSizes = [];
  if (product) {
    const selectedSizes = product.color[selectedImageIndex].sizes;
    sortedSizes = [...selectedSizes].sort(
      (a, b) => sizeOrderMap[a] - sizeOrderMap[b]
    );
  }

  const detailSections = [
    { label: "Fabric", value: product?.Fabric },
    { label: "Sleeve Styling", value: product?.sleeveStyling },
    { label: "Sleeve Length", value: product?.sleeveLength },
    { label: "Fit Shape", value: product?.fitShape },
    { label: "Neck", value: product?.Neck },
    { label: "Occasion", value: product?.occasion },
    { label: "Pattern", value: product?.pattern },
    { label: "Print/Pattern", value: product?.printOrpattern },
    { label: "Description", value: product?.Description },
  ];

  const SelectedSize = async () => {
    const existingCartItems = JSON.parse(localStorage.getItem("cart")) || [];
    const isSelectedInLocalCart = existingCartItems.some(
      (item) => item.productId === productId && item.size === selectedSize
    );
  
    if (token) {
      try {
        const response = await GetCartItemAPI([], token);
        const cartItems = response.cartItems || [];
  
        const isSelectedInAPI = cartItems.some(
          (item) => item._doc.productId === productId && item._doc.size === selectedSize
        );
  
        if (isSelectedInAPI || isSelectedInLocalCart) {
          setcartbtnindex(1);
        } else {
          setcartbtnindex(0);
        }
      } catch (error) {
        console.error("Error fetching cart items", error);
      }
    } else {
      if (isSelectedInLocalCart) {
        setcartbtnindex(1);
      } else {
        setcartbtnindex(0);
      }
    }
  };
  
  

  const AddToCart = async () => {
    if (!selectedSize) {
      toast.error("Please select a size before adding to cart.", {
        position: "top-center",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      return;
    }

    const cartItem = {
      productId: productId,
      size: selectedSize,
      color: selectedImageIndex,
      qty: 1,
    };

    if (!token) {
      const existingCartItems = JSON.parse(localStorage.getItem("cart")) || [];
      const updatedCartItems = [...existingCartItems, cartItem];

      localStorage.setItem("cart", JSON.stringify(updatedCartItems));

      toast.success("Item added to cart!", {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored",
      });
      setSelectedSize("");
    } else {
      try {
        const response = await AddCartItemAPI(token, cartItem);
        console.log("Response add to cart:", response);
        if (response.statusCode === 200) {
          toast.success("Item added to cart!", {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "colored",
          });
          setSelectedSize("");
        } else {
          console.error(
            "Failed to add cart. Status code:",
            response.statusCode
          );
        }
      } catch (error) {
        console.error("Error adding to cart:", error);
      }
    }
  };

  return (
    <div className="productView">
      <Navbar />
      <div className="lg:max-w-[1440px] mx-auto m-0 px-[50px] mt-[40px]">
        {product && (
          <div className={`flex gap-[20px]`}>
            {/* mobile view */}
            <div
              className={` flex ${
                product.color.length <= 1 ? "w-[30%]" : "w-[40%]"
              } lg:hidden`}
            >
              <div
                className={`full_image  relative ${
                  product.color.length <= 1 ? "w-[100%]" : "w-[80%]"
                }`}
              >
                <Slider {...sliderSettings}>
                  {product.color[selectedImageIndex].images.map(
                    (image, index) => (
                      <div key={index}>
                        <img
                          src={`http://localhost:7000/productimg/${image}`}
                          alt={`Product Image ${index}`}
                          className={` max-h-[400px] ${
                            product.color.length <= 1
                              ? "w-[400px]"
                              : "w-[400px]"
                          }`}
                        />
                      </div>
                    )
                  )}
                </Slider>
              </div>
            </div>

            <div className="w-[60%] md:block hidden">
              <div className="flex flex-wrap gap-[10px]">
                {product.color[selectedImageIndex].images.map(
                  (image, index) => (
                    <div key={index} className="w-[49%]">
                      <img
                        src={`http://localhost:7000/productimg/${image}`}
                        alt={`Product Image ${index}`}
                        className={` max-h-[494px] ${
                          product.color.length <= 1 ? "w-[100%]" : "w-[494px]"
                        }`}
                      />
                    </div>
                  )
                )}
              </div>
            </div>
            <div className="w-[40%]">
              <div className="flex gap-[5px] mb-[5px]">
                <p className="text-[#7e818c] text-[12px] font-roboto">
                  {product.category.toUpperCase()} :
                </p>
                <p className="text-[#7e818c] text-[12px] font-roboto">
                  {product.subcategory.toUpperCase()} :
                </p>
                <p className="text-[#7e818c] text-[12px] font-roboto">
                  {product.subcategoryitem.toUpperCase()}{" "}
                </p>
              </div>

              <div>
                <p className="text-[22px] font-roboto font-bold">
                  {product.productName.toUpperCase()}
                </p>
                <p className="text-[#7e818c] font-roboto text-[19px]">
                  {product.ShortDescription}
                </p>
              </div>

              <div className="flex mt-[10px] gap-[5px] items-center">
                <p className="text-[27px] font-roboto">
                  ₹{product.productPrice}
                </p>
                <p className="text-[#7e818c] text-[19px]">
                  MRP <del>₹{product.productMrp}</del>
                </p>
              </div>

              <div className="mt-[10px]">
                <p className="text-[17px] font-bold font-roboto mb-[5px]">
                  Select Size :
                </p>
                <div className="flex gap-[10px] flex-wrap">
                  {sortedSizes.map((sizeValue, index) => {
                    const sizeLabel =
                      ProductSizeData.find((size) => size.value === sizeValue)
                        ?.label || sizeValue;
                    return (
                      <p
                        key={index}
                        className={`border-[1px] border-[#7e818c] p-[10px] font-light font-roboto rounded-[50px] w-[45px] text-center cursor-pointer ${
                          selectedSize === sizeValue
                            ? "border-[#FF3E6C] text-[#FF3E6C]"
                            : ""
                        }`}
                        onClick={() => setSelectedSize(sizeValue)}
                      >
                        {sizeLabel}
                      </p>
                    );
                  })}
                </div>
              </div>
              <div
                className={`color_section ${
                  product.color.length <= 1 ? "hidden" : "block"
                } my-[10px] inline-block`}
              >
                <h2 className="text-[17px] font-bold font-roboto mb-[5px]">
                  MORE COLORS
                </h2>
                <div className="flex gap-x-[10px] mt-[5px]">
                  {product.color.map((colorOption, colorIndex) => (
                    <img
                      key={colorIndex}
                      src={`http://localhost:7000/productimg/${colorOption.images[0]}`}
                      alt={`Product Color ${colorOption.color}`}
                      className={`w-[60px] h-[65px] mb-2 cursor-pointer ${
                        colorIndex === selectedImageIndex
                          ? "border-[1px] border-[#f41cb2]"
                          : ""
                      }`}
                      onClick={() => setSelectedImageIndex(colorIndex)}
                    />
                  ))}
                </div>
              </div>

              <div className="flex mt-[20px] gap-x-[20px] pb-[40px] border-b-[1px]">
                {cartbtnindex === 0 ? (
                  <button
                    to="#"
                    className="bg-[#FF3E6C] text-[16px] font-roboto font-normal py-[15px] w-[60%] text-center text-white rounded-[11px]"
                    onClick={AddToCart}
                  >
                    ADD TO BAG
                  </button>
                ) : (
                  <Link
                    to="/bag"
                    className="bg-[#FF3E6C] text-[16px] font-roboto font-normal py-[15px] w-[60%] text-center text-white rounded-[11px]"
                  >
                    GO TO BAG
                  </Link>
                )}

                <button
                  to="#"
                  className="text-[16px] font-roboto font-normal py-[15px] w-[40%] text-center text-black border-[1px] rounded-[11px] hover:border-[1px] hover:border-black"
                >
                  WISHLIST
                </button>
              </div>

              <div className="mt-[40px]">
                <div className="">
                  <h5 className="text-[16px] font-roboto font-semibold">
                    DELIVERY OPTIONS
                  </h5>
                  <p className="text-[14px] font-roboto">
                    100% Original Products
                  </p>
                  <p className="text-[14px] font-roboto">
                    Pay on delivery might be available
                  </p>
                  <p className="text-[14px] font-roboto">
                    Easy 14 days returns and exchanges
                  </p>
                </div>

                <div className="mt-[10px]">
                  <h2 className="text-[16px] font-roboto font-semibold">
                    Specifications
                  </h2>
                  <div className="mt-[10px]">
                    <div className="flex gap-[20px]">
                      {detailSections.slice(0, 2).map((section, index) => (
                        <ProductDetailSection
                          key={index}
                          label={section.label}
                          value={section.value}
                        />
                      ))}
                    </div>

                    <div className="flex gap-[20px] mt-[10px]">
                      {detailSections.slice(2, 4).map((section, index) => (
                        <ProductDetailSection
                          key={index}
                          label={section.label}
                          value={section.value}
                        />
                      ))}
                    </div>

                    <div className="flex gap-[20px] mt-[10px]">
                      {detailSections.slice(4, 6).map((section, index) => (
                        <ProductDetailSection
                          key={index}
                          label={section.label}
                          value={section.value}
                        />
                      ))}
                    </div>

                    <div className="flex gap-[20px] mt-[10px]">
                      {detailSections.slice(6, 8).map((section, index) => (
                        <ProductDetailSection
                          key={index}
                          label={section.label}
                          value={section.value}
                        />
                      ))}
                    </div>

                    <div className="flex gap-[20px] mt-[10px]">
                      <ProductDetailSection
                        label={detailSections[8].label}
                        value={detailSections[8].value}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
      <ToastContainer />
    </div>
  );
};
