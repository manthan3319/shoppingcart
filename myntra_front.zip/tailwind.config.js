/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        roboto: ['Roboto', 'sans-serif'],
      },
      backgroundImage: theme => ({
        'bgmesho': 'linear-gradient(62deg, #0daaee, #0daaee, #0daaee, #0daaee)',
        'tometo': '#ff3f6c',
        'tranferbg': '#0be34d21',
      }),
      colors: {
        'pop': '#0be34d',
      },
    },
  },
  plugins: [],
}
