import React from 'react'

export const OwnDashboard = () => {
  return (
    <div>OwnDashboard</div>
  )
}
