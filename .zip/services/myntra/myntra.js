/**
 * This is for Contain function layer for contractor service.
 * @author manthan Vaghasiya
 *
 */

const ObjectId = require("mongodb").ObjectID;
const dbService = require("../../utilities/dbService");
const messages = require("../../utilities/messages");
const universal = require("../../utilities/universal");
const nodemailer = require('nodemailer');
const jwt = require('jsonwebtoken');

/*************************** AddNewMainAdmin ***************************/
const AddNewMainAdmin = async (req) => {
  const { email } = req.body;
  const password = await universal.encryptpassword(req.body.password);
  // console.log("password", password);
  if (email) {
    const data = {
      email: email,
      password: password
    }

    let owener = await dbService.createOneRecord("mainownerModel", data);
    // console.log(owener);
    return "Owner User Add sucessfuly";
  }
  else {
    return "owner not add"
  }
};

/*************************** LoginMainAdmin ***************************/
const LoginMainAdmin = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Email and Password are required!" });
  }

  const data = {
    email: email,
    isDeleted: false,
  };

  try {
    let contractorData = await dbService.findOneRecord("mainownerModel", data);
    console.log("Contractor Data:", contractorData);

    if (contractorData) {
      const passwordsMatch = await universal.decryptPassword(password, contractorData.password);

      if (passwordsMatch) {
        const userIdObj = { userId: contractorData._id };
        const token = await universal.generateJwtTokenFn(userIdObj);

        return {
          message: "Login successful!",
          token: token,
        };
      } else {
        return { message: "Password is incorrect!" };
      }
    } else {
      return { message: "Your Email is incorrect!" };
    }
  } catch (error) {
    console.error("Error in LoginMainAdmin:", error);
    return { message: "An error occurred!" };
  }
};

/*************************** AddCategory ***************************/
const AddCategory = async (req, res) => {
  const categories = req.body.categories;

  const addedCategories = [];
  const existingCategories = [];

  for (let category of categories) {
    const normalizedCategory = category.toLowerCase();

    const categorydata = {
      isDeleted: false,
      category: normalizedCategory
    };

    const getCategory = await dbService.findAllRecords("categoryModel", { category: normalizedCategory });

    if (getCategory.length > 0) {
      existingCategories.push(category);
    } else {
      const addCategory = await dbService.createManyRecords("categoryModel", [categorydata]);
      if (addCategory) {
        addedCategories.push(category);
      }
    }
  }

  return {
    existingCategories: existingCategories,
    addedCategories: addedCategories,
    message: "Category added and existing categories processed successfully"
  };
};

/*************************** getCategory ***************************/
const getCategory = async (req) => {
  const where = {
    isDeleted: false
  }
  const categoryData = await dbService.findAllRecords("categoryModel", where);
  if (categoryData) {
    return {
      messages: "category Data get successfully",
      categoryData: categoryData
    }
  } else {
    return "Category Data not Get"
  }
}

/*************************** AddSubCategory ***************************/
const AddSubCategory = async (req, res) => {
  const subcategory = req.body.AddSubCategory;
  const category = req.body.category.toLowerCase();
  const categoryData = await dbService.findOneRecord("categoryModel", { category: category });

  const addedSubCategories = [];
  const existingSubCategories = [];

  if (categoryData) {
    for (let subCategoryName of subcategory) {
      const normalizedSubCategory = subCategoryName.toLowerCase();

      const subcategoryData = {
        isDeleted: false,
        subcategory: normalizedSubCategory,
        category: categoryData.category,
        categoryid: categoryData._id,
      };

      // Check for the existence of the subcategory within the context of the specific category
      const subCategory = await dbService.findAllRecords("subcategoryModel", {
        subcategory: normalizedSubCategory,
        category: categoryData.category
      });

      if (subCategory.length > 0) {
        existingSubCategories.push(subCategoryName);
      } else {
        const addsubCategory = await dbService.createManyRecords("subcategoryModel", [subcategoryData]);
        // console.log("addsubCategory", addsubCategory);
        if (addsubCategory) {
          addedSubCategories.push(subCategoryName);
        }
      }
    }

    return {
            existingSubCategories: existingSubCategories,
            addedSubCategories: addedSubCategories,
            message: "Category added and existing categories processed successfully"
          };
  } else {
    return "category not define"
  }
};

/*************************** getSubCategory ***************************/
const getSubCategory = async (req) => {
  const where = {
    isDeleted: false
  }
  const subcategoryData = await dbService.findAllRecords("subcategoryModel", where);
  if (subcategoryData) {
    return {
      messages: "subcategory Data get successfully",
      subcategoryData: subcategoryData
    }
  } else {
    return "Subcategory Data not Get"
  }
}

/*************************** AddSubCategory ***************************/
const AddSubCategoryItem = async (req, res) => {
  // console.log("AddSubCategoryItem", req.body);
  const subcategoryitems = req.body.AddSubCategoryItem;
  const category = req.body.category.toLowerCase();
  const subcategory = req.body.subcategory.toLowerCase();

  const categoryData = await dbService.findOneRecord("categoryModel", { category: category });
  // console.log("categoryData", categoryData);

  const SubcategoryData = await dbService.findOneRecord("subcategoryModel", { subcategory: subcategory });
  // console.log("SubcategoryData", SubcategoryData);

  const addedSubCategoriesitem = [];
  const existingSubCategoriesitem = [];

  if (categoryData) {
    if (SubcategoryData) {
      for (let subCategoryItem of subcategoryitems) {
        const normalizedSubCategoryItem = subCategoryItem.toLowerCase();

        const subcategoryItemData = {
          isDeleted: false,
          subcategoryitem: normalizedSubCategoryItem,
          category: categoryData.category,
          categoryid: categoryData._id,
          subcategory: SubcategoryData.subcategory,
          subcategoryid: SubcategoryData._id
        };

        // Check for the existence of the subcategory item within the context of the specific category and subcategory
        const subCategoryItems = await dbService.findAllRecords("subcategoryItemModel", {
          subcategoryitem: normalizedSubCategoryItem,
          category: categoryData.category,
          subcategory: SubcategoryData.subcategory
        });

        if (subCategoryItems.length > 0) {
          existingSubCategoriesitem.push(subCategoryItem);
        } else {
          const addSubCategoryItem = await dbService.createManyRecords("subcategoryItemModel", [subcategoryItemData]);

          if (addSubCategoryItem) {
            addedSubCategoriesitem.push(subCategoryItem);
          }
        }
      }

      return {
                existingSubCategoriesitem: existingSubCategoriesitem,
                addedSubCategoriesitem: addedSubCategoriesitem,
                message: "subCategory item added and existing categories processed successfully"
              };
    } else {
      return "subcategory not define"
    }
  } else {
    return "category not define"
  }
};

/*************************** AddBrand ***************************/
const AddBrand = async (req) => {
  const brand = req.body.brand;

  const addedBrand = [];
  const existingBrand = [];

  for (let category of brand) {
    const normalizedCategory = category.toLowerCase();

    const Branddata = {
      isDeleted: false,
      brand: normalizedCategory
    };

    const getbrand = await dbService.findAllRecords("brandModel", { brand: normalizedCategory });

    if (getbrand.length > 0) {
      existingBrand.push(category);
    } else {
      const addCategory = await dbService.createManyRecords("brandModel", [Branddata]);
      if (addCategory) {
        addedBrand.push(category);
      }
    }
  }

  return {
    message: "Category added and existing categories processed successfully"
  };
};

/*************************** getIteamwithCategory ***************************/
const getIteamwithCategory = async (req) => {
  const category = req.body.category;
  console.log("category", category);

  const where = {
    isDeleted: false,
    category: category
  }
  const iteamData = await dbService.findAllRecords("subcategoryItemModel", where);
  console.log("iteamData", iteamData);
  if (iteamData) {
    return {
      messages: "iteam Data get successfully",
      iteamData: iteamData
    }
  } else {
    return "Category Data not Get"
  }
}

/*************************** AddCatalog ***************************/
const AddCatalog = async (req) => {
  try {
    const { category, subcategory, subcategoryitem, productName, ShortDescription,
      productPrice, productMrp, color, Fabric, sleeveStyling, sleeveLength,
      fitShape, Neck, occasion, pattern, printOrpattern, Description } = req.body;


    color.forEach((colorItem, index) => {
      colorItem.images.forEach((image, idx) => {
      });
    });

    const supplierId = await universal.decodeDirectJwtTokenFn(req.body.token);
    console.log("supplierId",supplierId);


    const catalogData = {
      category,
      subcategory,
      subcategoryitem,
      productName,
      ShortDescription,
      productPrice,
      productMrp,
      color,
      Fabric,
      sleeveStyling,
      sleeveLength,
      fitShape,
      Neck,
      occasion,
      pattern,
      printOrpattern,
      Description,
      supplierId:supplierId.userId
    };

    const addCatalogResult = await dbService.createOneRecord("productModel", catalogData);

    return { success: true, message: "Catalog added successfully" };
  } catch (error) {
    console.error("Error adding catalog:", error);
    throw new Error("Failed to add catalog");
  }
};

/*************************** getIteamwithCondition ***************************/
const getIteamwithCondition = async (req) => {

  const { category, subcategory, subcategoryitem, productId } = req.body;
  try {
    let query = {};

    if (category) {
      query.category = category.toLowerCase();
    }
    if (subcategory) {
      query.subcategory = subcategory.toLowerCase();
    }
    if (subcategoryitem) {
      query.subcategoryitem = subcategoryitem.toLowerCase();
    }
    if (productId) {
      query._id = productId;
    }
    // console.log("productdata",query)

    const iteamData = await dbService.findAllRecords("productModel", query);
    // console.log("productdata",iteamData)
    if (iteamData) {
      return {
        messages: "product data get successfully",
        iteamData: iteamData
      }
    } else {
      return "Category Data not Get"
    }
  } catch (error) {
    console.error("Error fetching items with condition:", error);
    throw error;
  }
};

/*************************** getCartIteam ***************************/
const getCartIteam = async (req) => {
  try {
    const { token, cartItems } = req.body;
    let CartItemData = [];

    if (token) {
      const decodedUser = await universal.decodeDirectJwtTokenFn(token);
      const { userId } = decodedUser;
      const userCartItems = await dbService.findAllRecords("cartItemModel", { userid: userId });

      for (const userCartItem of userCartItems) {
        const query = { _id: userCartItem.productId };
        const productDetails = await dbService.findOneRecord("productModel", query);

        if (productDetails) {
          const selectedColor = productDetails.color[userCartItem.color];
          const detailedCartItem = {
            ...userCartItem,
            category: productDetails.category,
            subcategory: productDetails.subcategory,
            subcategoryitem: productDetails.subcategoryitem,
            productName: productDetails.productName,
            ShortDescription: productDetails.ShortDescription,
            productPrice: productDetails.productPrice * userCartItem.qty,
            productMrp: productDetails.productMrp * userCartItem.qty,
            productSize: userCartItem.size, 
            qty: userCartItem.qty, 
            image: selectedColor.images[0],
            cartId:userCartItem._id
          };

          CartItemData.push(detailedCartItem);
        }
      }
    } else {
      const uniqueProductIds = [...new Set(cartItems.map(item => item.productId))];

      for (const productId of uniqueProductIds) {
        const cartItemsForProductId = cartItems.filter(item => item.productId === productId);
        const query = { _id: productId };
        const productDetails = await dbService.findOneRecord("productModel", query);

        if (productDetails) {
          for (const cartItem of cartItemsForProductId) {
            const selectedColor = productDetails.color[cartItem.color];
            const detailedCartItem = {
              ...cartItem,
              category: productDetails.category,
              subcategory: productDetails.subcategory,
              subcategoryitem: productDetails.subcategoryitem,
              productName: productDetails.productName,
              ShortDescription: productDetails.ShortDescription,
              productPrice: productDetails.productPrice * cartItem.qty,
              productMrp: productDetails.productMrp * cartItem.qty,
              productSize: cartItem.size, 
              qty: cartItem.qty, 
              image: selectedColor.images[0]
            };

            CartItemData.push(detailedCartItem);
          }
        }
      }
    }

    const totalCartPrice = CartItemData.reduce((total, item) => total + item.productPrice, 0);
    const totalCartMrp = CartItemData.reduce((total, item) => total + item.productMrp, 0);
    const totalQty = CartItemData.reduce((total, item) => total + item.qty, 0);

    return {
      cartItems: CartItemData,
      totalCartPrice,
      totalCartMrp,
      totalItem: CartItemData.length,
      totalQty
    };
  } catch (error) {
    console.error("Error fetching cart items:", error);
    throw error;
  }
};

/*************************** sendOtp ***************************/
const sendOtp = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).send({ message: 'Email is required' });
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    const transporter = nodemailer.createTransport({
      service: 'Gmail',
      auth: {
        user: 'vaghasiyamanthan5@gmail.com',
        pass: 'kbxedryninlmaxpl',
      },
    });

    const mailOptions = {
      from: 'vaghasiyamanthan5@gmail.com',
      to: email,
      subject: 'VERIFY OTP IN MYNTRA',
      text: `Your OTP code is ${otp}`,
    };


    const query = {
      isDeleted: false,
      email: email
    };

    const userotp = await dbService.findOneRecord("UserOtpModel", query);

    if (userotp) {
      const updateQuery = { email: email };
      const updateData = { $set: { otp: otp } };
      await dbService.updateManyRecords("UserOtpModel", updateQuery, updateData);
      await transporter.sendMail(mailOptions);

      console.log(`OTP sent to ${email}: ${otp}`);
      return { message: 'OTP sent successfully' };
    } else {
      const newOtpRecord = {
        isDeleted: false,
        email: email,
        otp: otp
      };
      await dbService.createOneRecord("UserOtpModel", newOtpRecord);
      await transporter.sendMail(mailOptions);

      console.log(`OTP sent to ${email}: ${otp}`);
      return { message: 'OTP sent and saved successfully' };
    }
  } catch (error) {
    console.error("Error fetching cart items:", error);
    throw error;
  }
};

/*************************** verifyOtp ***************************/
const verifyOtp = async (req) => {
  try {
    const { email, otp } = req.body;
    const verifyuser = { email, otp };

    const userdata = await dbService.findOneRecord("UserOtpModel", verifyuser);

    if (!userdata) {
      return { message: "OTP invalid" };
    }

    const where = { email };

    let getuserdata = await dbService.findOneRecord("UserModel", where);
    if (!getuserdata) {
      const newUser = await dbService.createOneRecord("UserModel", { email, loginToken: [] });
      getuserdata = await dbService.findOneRecord("UserModel", where);
      if (!getuserdata) {
        return { message: "User creation failed" };
      }
    }

    const userIdObj = { userId: getuserdata._id };
    const token = await universal.generateJwtTokenFn(userIdObj);

    await dbService.updateManyRecords("UserModel", where, { $set: { loginToken: [token] } });

    return {
      message: "Login successful!",
      token: token,
    };

  } catch (error) {
    console.error('Error verifying OTP:', error);
    return { message: "An error occurred during OTP verification" };
  }
};

/*************************** usercartitemadd ***************************/
const usercartitemadd = async (req) => {

  const { token, cartItems } = req.body;

  try {
    const decodedUser = await universal.decodeDirectJwtTokenFn(token);
    const { userId } = decodedUser;

    const promises = cartItems.map(async (item) => {
      const { productId, size, color, qty } = item;

      const where = {
        productId: productId,
        userid: userId, 
        color: color,
        size: size, 
        qty: qty
      };

      try {
        const addcartdatawithuserid = await dbService.createOneRecord("cartItemModel", where);
        console.log("CartItem added:", addcartdatawithuserid);
        return addcartdatawithuserid;
      } catch (error) {
        console.error("Error adding cart item:", error);
        throw error;
      }
    });

    const results = await Promise.all(promises);
    console.log("All cart items added successfully:", results);
    return results;
  } catch (error) {
    console.error("Error decoding JWT token:", error);
    throw error;
  }
};

/*************************** userCartItemRemove ***************************/
const userCartItemRemove = async (req) => {
  try {
    console.log("userCartItemRemove", req.body);
    const where = {
      isDeleted: false,
      _id: req.body.cartid,
    };

    const cardRecord = await dbService.findOneRecord("cartItemModel", where);
    console.log("cardRecord", cardRecord);

    if (cardRecord) {
      const result = await dbService.deleteOneRecordById("cartItemModel", cardRecord._id);
      return {
        messages:"cartitem Remove Sucessfuly"
      }
    } else {
      console.log("Record not found or already deleted");
    }
  } catch (error) {
    console.error("Error removing cart item:", error);
  }
};

/*************************** userCartItemRemove ***************************/
const updateCartItemQty = async (req) => {
  try {
    
    const { productId, qty, size, token } = req.body;
    
    const decodedUser = await universal.decodeDirectJwtTokenFn(token);
    
    const where = {
      isDeleted: false,
      productId: productId,
      userid: decodedUser.userId,
      size: size
    };

    const cardRecord = await dbService.findOneRecord("cartItemModel", where);
    
    if (!cardRecord) {
      return { error: "Cart item not found" };
    }
    const newQty = Math.max(1, qty);

    const updateResult = await dbService.updateManyRecords(
      "cartItemModel",
      where,
      { qty: newQty }
    );

    if (updateResult.modifiedCount === 0) {
      return { error: "Failed to update cart item" };
    }

    return { success: "Cart item updated successfully" };
  } catch (error) {
    console.error("Error updating cart item:", error);
    return { error: error.message };
  }
};

/*************************** userCartItemRemove ***************************/
const adduseradress = async (req) => {
  const decodedUser = await universal.decodeDirectJwtTokenFn(req.body.usertoken);

  const addressData = {
    userid:decodedUser.userId,
    name:req.body.name,
    number:req.body.number,
    pincode:req.body.pincode,
    address:req.body.address,
    locality:req.body.locality,
    state:req.body.state,
  }
   
  if(addressData){
        const add = await dbService.createOneRecord("useraddressModel",addressData);

        if(add){
          return{
            messages: "address add"
          }
        }else{
          return { error: error.message };
        }
  }

  
}



module.exports = {
  AddNewMainAdmin,
  LoginMainAdmin,
  AddCategory,
  getCategory,
  AddSubCategory,
  getSubCategory,
  AddSubCategoryItem,
  AddBrand,
  getIteamwithCategory,
  AddCatalog,
  getIteamwithCondition,
  getCartIteam,
  sendOtp,
  verifyOtp,
  usercartitemadd,
  userCartItemRemove,
  updateCartItemQty,
  adduseradress
};
