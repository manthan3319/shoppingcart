import React from 'react';
import './index.css';
import reportWebVitals from './reportWebVitals';
import {App} from "./App"
import { BrowserRouter } from 'react-router-dom';
import 'font-awesome/css/font-awesome.min.css';
import '@fontsource/roboto'; 
import '@fontsource/roboto/500.css'; 
import '@fontsource/roboto/700.css'; 
import ReactDOM from 'react-dom/client'; 

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
    <App />
  </BrowserRouter>
);

reportWebVitals();