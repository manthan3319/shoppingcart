import React from 'react';
import { SaidBar } from '../SaidBar/SaidBar';
import '../../mainadmin.css';
import { useLocation } from 'react-router-dom';
import { OwnAddCategory } from '../OwnAddCategory/OwnAddCategory';
import { OwnDashboard } from '../OwnDashboard/OwnDashboard';
import { useTokenRequire } from '../../../Function/Function';
import { CatalogUploads } from '../CatalogUploads/CatalogUploads';
import { HelpPrictice } from '../HelpPrictice';
export const OwnerPanel = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const OwnAddCategorypath = searchParams.get('OwnAddCategory');
  const CatalogUploadspath = searchParams.get('CatalogUploads');
  const demopath = searchParams.get('demo');
  const ownerPanelpath = location.pathname;

  useTokenRequire('/owner');

  return (
    <div>
      <SaidBar />
      <div className='lg:max-w-[1440px] w-[82.8%] ml-[217px] px-[50px] bg-[#eee] py-[10px] h-[100%] min-h-[100vh]'>
        {ownerPanelpath === '/ownerPanel' && <OwnDashboard />}
        {OwnAddCategorypath && <OwnAddCategory />}
        {CatalogUploadspath && <CatalogUploads />}
        {demopath && <HelpPrictice/>}
      </div>
    </div>
  );
};
