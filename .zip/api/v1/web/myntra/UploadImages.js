/**
 * This is the Image Upload API.
 * Author: Manthan Vaghasiya
 */

const { Router } = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const router = new Router();

// Configure multer storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadPath = path.join(__dirname, '../../../../productimg');
    fs.mkdirSync(uploadPath, { recursive: true });  // Ensure directory exists
    cb(null, uploadPath);
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname); // Keep the original filename
  },
  
});

const upload = multer({ storage });

/**
 * @swagger
 * /api/v1/Myntra/UploadImages:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Upload product images.
 *   description: API used for uploading product images.
 *   consumes:
 *     - multipart/form-data
 *   parameters:
 *     - in: formData
 *       name: images
 *       description: Product images.
 *       required: true
 *       type: array
 *       items:
 *         type: file
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */

router.post(
  "/UploadImages",
  upload.array('images', 10), 
  (req, res) => {
    try {
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: "You must upload at least one image." });
      }
      
      const uploadedImages = req.files.map(file => file.filename);
      const existingImages = fs.readdirSync(path.join(__dirname, '../../../../productimg'));
      
      const newImages = uploadedImages.filter(image => !existingImages.includes(image));

     

      res.status(200).json({ message: "Images uploaded successfully.", images: newImages });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }
);

module.exports = router;
