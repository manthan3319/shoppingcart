/*
 * @file: index.js
 * @description: It's combine all routers.
 * @author: manthan Vaghasiya
 */
const { Router } = require("express");
const app = Router();

const contractor = require("./contractor");
const myntra = require("./myntra")
/*********** Combine all Routes ********************/
app.use("/contractor", contractor);
app.use("/myntra",myntra);
module.exports = app;
