import React from "react";
import { GoogleLogin } from "react-google-login";
import { Link } from "react-router-dom";
import {
  Flat400,
  BannerMan,
  CouponCorner,
  my100off,
  my200off,
  crazydeals,
  installapp,
} from "../../Images/Images";
import { ShopCategory } from "./ShopCategory";
import { CrazyDeals } from "./CrazyDeals";
import { Footer } from "../Footer/Footer";

export const LandingBanner = () => {
  return (
    <>
      <div className="lg:max-w-[1440px] mx-auto m-0 px-[50px] ">
        <div className="mt-[20px]">
          <div>
            <Link>
              <img src={Flat400} alt="Flat400" />
            </Link>
          </div>
          <div>
            <Link>
              {" "}
              <img src={BannerMan} alt="banner" />
            </Link>
          </div>

          <div>
            <img src={CouponCorner} alt="CouponCorner" />
          </div>

          <div className="flex gap-x-7">
            <div>
              <Link>
                {" "}
                <img src={my100off} alt="my100off" />
              </Link>
            </div>
            <div>
              <Link>
                <img src={my200off} alt="my200off" />
              </Link>
            </div>
          </div>

          <div className="mt-[20px]">
            <img src={crazydeals} alt="CouponCorner" />
          </div>
        </div>
        <div>
          <CrazyDeals />
        </div>

        <div>
          <ShopCategory />
        </div>

        <div className="mt-[50px]">
          <img src={installapp} alt="install" />
        </div>
      </div>
      <div>
        <Footer />
      </div>
    </>
  );
};
