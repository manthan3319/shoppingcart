
export const config = {
    apiBaseUrl: 'http://localhost:7000',
  };
  