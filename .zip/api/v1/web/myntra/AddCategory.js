/**
 * This is Contain Save router/api.
 * @author manthan Vaghasiya
 *
 */

const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { AddCategory } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/AddCategory:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Save Category information.
 *   description: api used for saving category information.
 *   parameters:
 *      - in: body
 *        name: lead
 *        description: Save category information.
 *        schema:
 *         type: object
 *         properties:
 *           categories:
 *             type: array
 *             items:
 *               type: string
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */

const dataSchema = Joi.object({
  categories: Joi.array().items(Joi.string().required()).required().label("categories"),
});

router.post(
  "/AddCategory",
  commonResolver.bind({
    modelService: AddCategory,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);

module.exports = router;
