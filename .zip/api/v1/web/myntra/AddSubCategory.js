/**
 * This is Contain Save router/api.
 * @author manthan Vaghasiya
 *
 */

const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { AddSubCategory } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/AddSubCategory:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Save AddSubCategory information.
 *   description: api used for saving AddSubCategory information.
 *   parameters:
 *      - in: body
 *        name: lead
 *        description: Save AddSubCategory information.
 *        schema:
 *         type: object
 *         properties:
 *           AddSubCategory:
 *             type: array
 *             items:
 *               type: string
 *           category:
 *               type: string
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */

const dataSchema = Joi.object({
  AddSubCategory: Joi.array().items(Joi.string().required()).required().label("AddSubCategory"),
  category: Joi.string().required("category"),
});

router.post(
  "/AddSubCategory",
  commonResolver.bind({
    modelService: AddSubCategory,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);

module.exports = router;
