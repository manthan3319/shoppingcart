import React, { useState, useEffect, useCallback } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { CustomHeader } from '../../../Function/Function';
import { pluseicon, removeicon } from '../../../Images/Images';
import { config } from '../../../config';

export const OwnAddCategory = () => {
  const [selectedCategory, setSelectedCategory] = useState('Main Category');
  const [inputFields, setInputFields] = useState(['']);
  const [subcategoryFields, setSubcategoryFields] = useState(['']);
  const [categoryData, setCategoryData] = useState([]);
  const [subcategoryData, setSubcategoryData] = useState([]);
  const [selectedMainCategory, setSelectedMainCategory] = useState('men');
  const [selectedSubCategory, setSelectedSubCategory] = useState('Topwear');

  // console.log("subcategoryData0",subcategoryData);

  const handleCategoryChange = (e) => setSelectedCategory(e.target.value);

  const handleInputChange = (index, e, setFields, fields) => {
    const values = [...fields];
    values[index] = e.target.value;
    setFields(values);
  };

  const handleAddField = (setFields, fields) => {
    setFields([...fields, '']);
  };

  const handleRemoveField = (index, setFields, fields) => {
    const values = [...fields];
    values.splice(index, 1);
    setFields(values);
  };

  const handleSubmit = async (url, data, successMessage, resetFields) => {
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!response.ok) throw new Error('Network response was not ok');
      const result = await response.json();

      if (result) {
        toast.success(successMessage, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          progress: undefined,
          theme: "colored"
        });

        resetFields();
      }
    } catch (error) {
      console.error('Error:', error);
      toast.error('Please add valid data!', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        theme: "colored"
      });
    }
  };

  const fetchData = useCallback(async (url, setData) => {
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}),
      });

      if (!response.ok) throw new Error('Failed to fetch data');

      const result = await response.json();
      setData(result.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }, []);

  useEffect(() => {
    if (selectedCategory === 'sub category' || selectedCategory === 'item') {
      fetchData(`${config.apiBaseUrl}/api/v1/Myntra/getCategory`, (data) => setCategoryData(data.categoryData));
    }

    if (selectedCategory === 'item') {
      fetchData(`${config.apiBaseUrl}/api/v1/Myntra/getSubCategory`, (data) => setSubcategoryData(data.subcategoryData));
    }
  }, [selectedCategory, fetchData]);

  // Filter subcategories based on the selected main category
  const filteredSubcategories = subcategoryData.filter(subcategory => subcategory.category === selectedMainCategory);
  return (
    <div >
      <div>
        <CustomHeader text="Add Category" link="/ownerPanel" />
      </div>

      <div className='mt-[30px]'>
        <div className='category_add_from rounded-t-[8px]'>
          <div className='category_oprion'>
            <select className='w-[100%] outline-none text-[15px] font-roboto' value={selectedCategory} onChange={handleCategoryChange}>
              <option value="Main Category">Main Category</option>
              <option value="sub category">Sub Category</option>
              <option value="item">SubCategory item</option>
              <option value="Brand">Brand</option>
            </select>
          </div>
        </div>

        <div className='mt-[10px]'>
          {selectedCategory === 'Main Category' && (
            <div className='category_add_from'>
              {inputFields.map((field, index) => (
                <div key={index} className='flex items-center mt-2'>
                  <input
                    type='text'
                    value={field}
                    onChange={(e) => handleInputChange(index, e, setInputFields, inputFields)}
                    className='mr-2 p-1 border border-gray-300 w-[100%] rounded outline-none'
                  />
                  <button onClick={() => handleAddField(setInputFields, inputFields)} className='mr-2 p-1 text-white rounded'>
                    <img src={pluseicon} className='w-[23px]' alt='plus' />
                  </button>
                  {inputFields.length > 1 && (
                    <button onClick={() => handleRemoveField(index, setInputFields, inputFields)} className='p-1 text-white rounded'>
                      <img src={removeicon} className='w-[23px]' alt='remove' />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {selectedCategory === 'Main Category' && (
          <div className='mt-[10px]'>
            <div className='category_add_from text-center rounded-b-[7px]'>
              <button
                className='bg-bgmesho text-center w-[100%] p-[10px] text-white rounded-[7px] font-medium font-roboto max-w-[200px]'
                onClick={() => handleSubmit(
                  `${config.apiBaseUrl}/api/v1/Myntra/AddCategory`,
                  { categories: inputFields.filter(field => field.trim() !== '') },
                  'Category added successfully!',
                  () => setInputFields([''])
                )}
              >
                Add Category
              </button>
            </div>
          </div>
        )}

        {selectedCategory === 'sub category' && categoryData.length > 0 && (
          <div className='subcategory_section'>
            <div className='category_add_from'>
              <p className='text-black font-roboto text-[13px]'>Select Category</p>
              <select className='w-[100%] outline-none mt-[10px] font-roboto text-[15px]' value={selectedMainCategory} onChange={(e) => setSelectedMainCategory(e.target.value)}>
                {categoryData.map((category) => (
                  <option key={category._id} value={category.category} className='text-[15px] font-roboto'>{category.category}</option>
                ))}
              </select>
            </div>

            <div className='mt-[10px]'>
              <div className='category_add_from'>
                <p className='text-black font-roboto text-[13px]'>Add Subcategory</p>
                {subcategoryFields.map((field, index) => (
                  <div key={index} className='flex items-center mt-2'>
                    <input
                      type='text'
                      value={field}
                      onChange={(e) => handleInputChange(index, e, setSubcategoryFields, subcategoryFields)}
                      className='mr-2 p-1 border border-gray-300 w-[100%] rounded outline-none'
                    />
                    <button onClick={() => handleAddField(setSubcategoryFields, subcategoryFields)} className='mr-2 p-1 text-white rounded'>
                      <img src={pluseicon} className='w-[23px]' alt='plus' />
                    </button>
                    {subcategoryFields.length > 1 && (
                      <button onClick={() => handleRemoveField(index, setSubcategoryFields, subcategoryFields)} className='p-1 text-white rounded'>
                        <img src={removeicon} className='w-[23px]' alt='remove' />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {selectedCategory === 'sub category' && (
          <div className='mt-[10px]'>
            <div className='category_add_from text-center rounded-b-[7px]'>
              <button
                className='bg-bgmesho text-center w-[100%] p-[10px] text-white rounded-[7px] font-medium font-roboto max-w-[200px]'
                onClick={() => handleSubmit(
                  `${config.apiBaseUrl}/api/v1/Myntra/AddSubCategory`,
                  {
                    AddSubCategory: subcategoryFields.filter(field => field.trim() !== ''),
                    category: selectedMainCategory,
                  },
                  'Subcategory added successfully!',
                  () => setSubcategoryFields([''])
                )}
              >
                Add SubCategory
              </button>
            </div>
          </div>
        )}

        {selectedCategory === 'item' && categoryData.length > 0 && subcategoryData.length > 0 && (
          <div className='item_section'>
            <div className='category_add_from'>
              <p className='text-black font-roboto text-[13px]'>Select Category</p>
              <select className='w-[100%] outline-none mt-[10px] font-roboto text-[15px]' value={selectedMainCategory} onChange={(e) => setSelectedMainCategory(e.target.value)}>
                {categoryData.map((category) => (
                  <option key={category._id} value={category.category} className='text-[15px] font-roboto'>{category.category}</option>
                ))}
              </select>
            </div>

            <div className='category_add_from mt-[10px]'>
              <p className='text-black font-roboto text-[13px]'>Select SubCategory</p>
              <select className='w-[100%] outline-none mt-[10px] font-roboto text-[15px]' value={selectedSubCategory} onChange={(e) => setSelectedSubCategory(e.target.value)}>
                {filteredSubcategories.map((subcategory) => (
                  <option key={subcategory._id} value={subcategory.subcategory} className='text-[15px] font-roboto'>{subcategory.subcategory}</option>
                ))}
              </select>
            </div>

            <div className='mt-[10px]'>
              <div className='category_add_from'>
                <p className='text-black font-roboto text-[13px]'>Add Item</p>
                {inputFields.map((field, index) => (
                  <div key={index} className='flex items-center mt-2'>
                    <input
                      type='text'
                      value={field}
                      onChange={(e) => handleInputChange(index, e, setInputFields, inputFields)}
                      className='mr-2 p-1 border border-gray-300 w-[100%] rounded outline-none'
                    />
                    <button onClick={() => handleAddField(setInputFields, inputFields)} className='mr-2 p-1 text-white rounded'>
                      <img src={pluseicon} className='w-[23px]' alt='plus' />
                    </button>
                    {inputFields.length > 1 && (
                      <button onClick={() => handleRemoveField(index, setInputFields, inputFields)} className='p-1 text-white rounded'>
                        <img src={removeicon} className='w-[23px]' alt='remove' />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {selectedCategory === 'item' && (
          <div className='mt-[10px]'>
            <div className='category_add_from text-center rounded-b-[7px]'>
              <button
                className='bg-bgmesho text-center w-[100%] p-[10px] text-white rounded-[7px] font-medium font-roboto max-w-[200px]'
                onClick={() => handleSubmit(
                  `${config.apiBaseUrl}/api/v1/Myntra/AddSubCategoryItem`,
                  {
                    AddSubCategoryItem: inputFields.filter(field => field.trim() !== ''),
                    category: selectedMainCategory,
                    subcategory: selectedSubCategory,
                  },
                  'Item added successfully!',
                  () => setInputFields([''])
                )}
              >
                Add Item
              </button>
            </div>
          </div>
        )}

        {selectedCategory === 'Brand' && (
          <div className='brand_section'>
            <div className='category_add_from'>
              <p className='text-black font-roboto text-[13px]'>Add Brand</p>
              {inputFields.map((field, index) => (
                <div key={index} className='flex items-center mt-2'>
                  <input
                    type='text'
                    value={field}
                    onChange={(e) => handleInputChange(index, e, setInputFields, inputFields)}
                    className='mr-2 p-1 border border-gray-300 w-[100%] rounded outline-none'
                  />
                  <button onClick={() => handleAddField(setInputFields, inputFields)} className='mr-2 p-1 text-white rounded'>
                    <img src={pluseicon} className='w-[23px]' alt='plus' />
                  </button>
                  {inputFields.length > 1 && (
                    <button onClick={() => handleRemoveField(index, setInputFields, inputFields)} className='p-1 text-white rounded'>
                      <img src={removeicon} className='w-[23px]' alt='remove' />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {selectedCategory === 'Brand' && (
          <div className='mt-[10px]'>
            <div className='category_add_from text-center rounded-b-[7px]'>
              <button
                className='bg-bgmesho text-center w-[100%] p-[10px] text-white rounded-[7px] font-medium font-roboto max-w-[200px]'
                onClick={() => handleSubmit(
                  `${config.apiBaseUrl}/api/v1/Myntra/AddBrand`,
                  { brand: inputFields.filter(field => field.trim() !== '') },
                  'Brand added successfully!',
                  () => setInputFields([''])
                )}
              >
                Add Brand
              </button>
            </div>
          </div>
        )}
      </div>

      <ToastContainer />
    </div>
  );
};
