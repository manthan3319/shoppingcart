import {
    category,
    uploadicon
} from "../Images/Images";

export const NavbarMenu = [
    {
        title: "MEN",
        subcategories: [
            {
                title: "Topwear",
                iteam: ["T-Shirts", "Casual Shirts", "Formal Shirts", "Sweatshirts", "Sweaters", "Jackets", "Blazers & Coats"]
            },
            {
                title: "Bottomwear",
                iteam: ["Jeans", "Casual Trousers", "Formal Trousers", "Shorts", "Track Pants & Joggers", "Innerwear & Sleepwear"]
            },
            {
                title: "Footwear",
                iteam: ["Casual Shoes", "Sports Shoes", "Formal Shoes", "Sneakers", "Sandals & Floaters", "Flip Flops"]
            },
            {
                title: "Sports & Active Wear",
                iteam: ["Sports Shoes", "Sports Sandals", "Active T-Shirts", "Track Pants & Shorts", "Tracksuits", "Jackets & Sweatshirts", "Sports Accessories"]
            },
            {
                title: "Fashion Accessories",
                iteam: ["Wallets", "Belts", "Perfumes & Body Mists", "Trimmers", "Deodorants", "Ties, Cufflinks & Pocket Squares", "Accessory Gift Sets", "Caps & Hats", "Mufflers, Scarves & Gloves"]
            },
            {
                title: "Indian & Festive Wear",
                iteam: ["Kurtas & Kurta Sets", "Sherwanis", "Nehru Jackets", "Dhotis"]
            },
            {
                title: "Innerwear & Sleepwear",
                iteam: ["Innerwear & Sleepwear", "Briefs & Trunks", "Boxers", "Vests", "Sleepwear & Loungewear"]
            },
            {
                title: "Personal Care & Grooming",
                iteam: ["Sunglasses & Frames", "Watches"]
            },
            {
                title: "Gadgets",
                iteam: ["Smart Wearables", "Fitness Gadgets", "Headphones", "Speakers"]
            }
        ]
    },
    {
        title: "Women",
        subcategories: [
            {
                title: "Indian & Fusion Wear",
                iteam: ["Kurtas & Suits", "Kurtis, Tunics & Tops", "Sarees", "Ethnic Wear", "Leggings, Salwars & Churidars", "Skirts & Palazzos", "Dress Materials", "Lehenga Cholis"]
            },
            {
                title: "Western Wear",
                iteam: ["Dresses", "Tops", "Tshirts", "Jeans", "Trousers & Capris", "Shorts & Skirts", "Co-ords", "Playsuits", "Jumpsuits", "Shrugs", "Sweaters & Sweatshirts"]
            },
            {
                title: "Maternity",
                iteam: ["Maternity", "Footwear", "Flats", "Casual Shoes", "Heels", "Boots", "Sports Shoes & Floaters"]
            },
            {
                title: "Sports & Active Wear",
                iteam: ["Clothing", "Footwear", "Sports Accessories", "Sports Equipment"]
            },
            {
                title: "Belts, Scarves & More",
                iteam: ["Watches & Wearables"]
            },
            {
                title: "Plus Size"
            },
        ]
    },
    {
        title: "Kids",
        subcategories: [
            {
                title: "Boys Clothing",
                iteam: ["T-Shirts", "Shirts", "Shorts", "Jeans", "Trousers", "Clothing Sets", "Ethnic Wear", "Track Pants & Pyjamas", "Jacket, Sweater & Sweatshirts", "Party Wear", "Innerwear & Thermals", "Nightwear & Loungewear", "Value Packs"]
            },
            {
                title: "Girls Clothing",
                iteam: ["Dresses", "Tops", "Tshirts", "Clothing Sets", "Lehenga choli", "Kurta Sets", "Party wear", "Dungarees & Jumpsuits", "Skirts & shorts", "Tights & Leggings", "Jeans, Trousers & Capris", "Jacket, Sweater & Sweatshirts", "Innerwear & Thermals", "Nightwear & Loungewear"]
            },
            {
                title: "Footwear",
                iteam: ["Casual Shoes", "Flipflops", "Sports Shoes", "Flats", "Sandals", "Heels", "School Shoes", "Socks"]
            },
            {
                title: "Toys & Games",
                iteam: ["Learning & Development", "Activity Toys", "Soft Toys", "Action Figure / Play set"]
            },
            {
                title: "Infants",
                iteam: ["Bodysuits", "Rompers & Sleepsuits", "Clothing Sets", "Tshirts & Tops"]
            }
        ]
    },
    {
        title: "Home & Living"
    },
    {
        title: "Beauty"
    },
    {
        title: "Studio"
    },
]

export const FooterMenu = [
    {
        title: "ONLINE SHOPPING",
        iteam: ["Men", "Women", "Kids", "Home & Living", "Beauty", "Gift Cards", "Myntra Insider"]
    },
    {
        title: "CUSTOMER POLICIES",
        iteam: ["Contact Us", "FAQ", "T&C", "Terms Of Use", "Track Orders", "Shipping", "Cancellation", "Returns", "Privacy policy", "Grievance Officer"]
    },
    {
        title: "USEFUL LINKS",
        iteam: ["Blog", "Careers", "Site Map", "Corporate Information", "Whitehat", "Cleartrip"]
    }
]

export const POPULARSEARCHES = [
    "Punjabi Suit", "Anarkali", "Lingerie", "Rakhi 2020", "Wedges",
    "Jacket For Women", "Bra", "Leggings", "Kanjeevaram Saree",
    "Dupattas", "Anklet", "Jeggings", "Panties", "Image", "W",
    "Samsung", "Cat", "Saree", "Dresses", "Palazzo Pants", "Shrugs",
    "Lehenga", "Kurtas", "Earrings", "Bikini", "Women Sweaters",
    "Swimwear", "Nightwear", "Nail Polish", "Halter Bra",
    "Dungarees", "Georgette Saree", "Watches", "Makeup", "Necklace",
    "Sharara", "Hot Pant", "Cotton Salwar Suit", "Rompers",
    "Nightdresses", "Skirts", "Stockings", "Women Shirts",
    "Eyeliner", "Lipstick", "Bangles", "Designer Blouses",
    "Tops", "One Piece Dresses", "Gowns"
];


export const ProductData = [
    // {
    //     id: 1,
    //     Category: "MEN",
    //     subcategories: [
    //         {
    //             subcategoriesName: "Topwear",
    //             iteam: [
    //                 {
    //                     iteamName: "T-Shirts",
    //                     iteamData: [
    //                         {
    //                             productName: "U.S. Polo Assn.",
    //                             shortDescription: "Men Lightweight Lounge T-shirt",
    //                             price: 485,
    //                             mrp: 699,
    //                             longDescription: "Men Embroidered Logo Pure Cotton Lightweight Lounge T-shirt",
    //                             Reating: 4,
    //                             images: [
    //                                 productimgmen1,
    //                                 productimgmen2,
    //                                 productimgmen3,
    //                                 productimgmen4,
    //                                 productimgmen5,
    //                                 productimgmen6,
    //                             ],
    //                             size: ["S", "M", "L", "XL", "XXL"],
    //                             productDetails: `Pack of 1 blue lounge T-shirt, has a round neck, short sleeves
    //                             Short sleeves for easy and unrestricted movement
    //                             The pure cotton fabric has better breathability and absorbency
    //                             Knit construction ensures the material is lightweight and comfortable`,
    //                             Features: `Ribbed crew neck ensures shape retention that withstands repeated wash and wear
    //                             Short sleeves for easy and unrestricted movement
    //                             Minimal logo at the chest provides signature branding
    //                             The product is tagless to provide a smooth surface and minimises any irritation
    //                             The versatile solid pattern works with all outfits
    //                             Knit construction ensures the material is lightweight and comfortable
    //                             The comfort fit ensures you have more space in the chest and torso area`,
    //                             MaterialCare: ["100% Cotton", "Machine wash"],
    //                             Specifications: [
    //                                 {
    //                                     Fabric: "Cotton",
    //                                     Neck: "Round Neck",
    //                                     Pattern: "Solid",
    //                                     SleeveLength: "Short Sleeves",
    //                                     Sustainable: "Regular",
    //                                     Type: "Regular",
    //                                     WashCare: "Machine Wash"
    //                                 }
    //                             ],
    //                             Seller: "Supercom Net"
    //                         }
    //                     ]
    //                 }
    //             ]
    //         }
    //     ]
    // }
];

export const MainAdminSaidbar = [
    {
        id: 1,
        Link: 'OwnAddCategory=true',
        Name: 'Category',
        logo: category, 
    },
    {
        id:2,
        Link: "CatalogUploads=true",
        Name: 'Catalog Uploads',
        logo: uploadicon,
    },
    {
        id:3,
        Link: "demo=true",
        Name: 'demo',
        logo: uploadicon,
    }
    
];


export const ProductSizeData = [
    { value: "XXS", label: "XXS" },
    { value: "XS", label: "XS" },
    { value: "S", label: "S" },
    { value: "M", label: "M" },
    { value: "L", label: "L" },
    { value: "XL", label: "XL" },
    { value: "XXL", label: "XXL" },
    { value: "XXXL", label: "XXXL" },
    { value: "4XL", label: "4XL" },
    { value: "5XL", label: "5XL" },
    { value: "6XL", label: "6XL" },
    { value: "7XL", label: "7XL" },
    { value: "8XL", label: "8XL" },
    { value: "9XL", label: "9XL" },
    { value: "10XL", label: "10XL" },
    { value: "Free Size", label: "Free Size" },
    { value: "LX", label: "LX" },
    { value: "SM", label: "SM" }
  ];
  
export const ProductColor = [
    { value: "black", label: "black" },
    { value: "red", label: "red" },
    { value: "blue", label: "blue" },
    { value: "white", label: "white" }
  ];

export const productFabric = [
    {value: "acrylic", label: "Acrylic"},
    {value: "artsilk", label: "Art Silk"},
    {value: "bamboo", label: "Bamboo"},
    {value: "chambray", label: "Chambray"},
    {value: "chandericotton", label: "Chanderi Cotton"},
    {value: "chanderislik", label: "chanderi Silk"},
    {value: "Chiffon", label: "Chiffon"},
    {value: "Cotton", label: "Cotton"},
    {value: "CottonBlend", label: "Cotton Blend"},
    {value: "CottonCambric", label: "Cotton Cambric"},
    {value: "CottonLinen", label: "Cotton Linen"},
    {value: "CottonSilk", label: "Cotton Silk"},
    {value: "Crepe", label: "Crepe"},
    {value: "Denim", label: "Denim"},
    {value: "DupionSilk", label: "Dupion Silk"},
    {value: "Elastane", label: "Elastane"},
    {value: "Georgette", label: "Georgette"},
    {value: "Jacquard", label: "Jacquard"},
    {value: "JuteCotton", label: "Jute Cotton"},
    {value: "JuteSilk", label: "Jute Silk"},
    {value: "KhadiCotton", label: "Khadi Cotton"},
    {value: "KoraMuslin", label: "Kora Muslin"},
    {value: "Lace", label: "Lace"},
    {value: "Linen", label: "Linen"},
    {value: "Lycra", label: "Lycra"},
    {value: "Microfibre", label: "Microfibre"},
    {value: "Modal", label: "Modal"},
    {value: "Mulmul", label: "Mulmul"},
    {value: "Net", label: "Net"},
    {value: "Nylon", label: "Nylon"},
    {value: "LaOrganzace", label: "Organza"},
    {value: "PaperSilk", label: "Paper Silk"},
    {value: "Pashmina", label: "Pashmina"},
    {value: "PolyBlend", label: "Poly Blend"},
    {value: "PolyChiffon", label: "Poly Chiffon"},
    {value: "PolyCrepe", label: "Poly Crepe"},
    {value: "PolyGeorgette", label: "Poly Georgette"},
    {value: "PolySilk", label: "Poly Silk"},
    {value: "Polycotton", label: "Polycotton"},
    {value: "Polyester", label: "Polyester"},
    {value: "Popcorn", label: "Popcorn"},
    {value: "Rayon", label: "Rayon"},
    {value: "Rayon Slub", label: "Rayon Slub"},
    {value: "Satin", label: "Satin"},
    {value: "Shantoon", label: "Shantoon"},
    {value: "Silk", label: "Silk"},
    {value: "SilkBlend", label: "Silk Blend"},
    {value: "SoftSilk", label: "Soft Silk"},
    {value: "Super Net", label: "Super Net"},
    {value: "Supima Cotton", label: "Supima Cotton"},
    {value: "Synthetic", label: "Synthetic"},
    {value: "Taffeta Silk", label: "Taffeta Silk"},
    {value: "Tissue", label: "Tissue"},
    {value: "Tussar Silk", label: "Tussar Silk"},
    {value: "Velvet", label: "Velvet"},
    {value: "Vichitra Silk", label: "Vichitra Silk"},
    {value: "Viscose Rayon", label: "Viscose Rayon"},
    {value: "Voile", label: "Voile"},
    {value: "Wool", label: "Wool"},
];

export const productSleeveStyling = [
    { value: "Cuffed", label: "Cuffed" },
    { value: "Doctor Sleeves", label: "Doctor Sleeves" },
    { value: "Elbow Patches", label: "Elbow Patches" },
    { value: "Raglan", label: "Raglan" },
    { value: "Regular", label: "Regular" },
    { value: "Roll-Up", label: "Roll-Up" },
    { value: "Sleeveless", label: "Sleeveless" },
    { value: "Thumbhole", label: "Thumbhole" },
];


export const productSleeveLength = [
    { value: "Long Sleeves", label: "Long Sleeves" },
    { value: "Short Sleeves", label: "Short Sleeves" },
    { value: "Sleeveless", label: "Sleeveless" },
    { value: "Three-Quarter Sleeves", label: "Three-Quarter Sleeves" },
];

export const productFitShape = [
    { value: "Boxy", label: "Boxy" },
    { value: "Compression", label: "Compression" },
    { value: "Loose", label: "Loose" },
    { value: "Oversize", label: "Oversize" },
    { value: "Regular", label: "Regular" },
    { value: "Relaxed", label: "Relaxed" },
    { value: "Slim", label: "Slim" },
    { value: "Tailored", label: "Tailored" },
];


export const productNeck = [
    { value: "Contrast Collar", label: "Contrast Collar" },
    { value: "Cowl", label: "Cowl" },
    { value: "Dual Collar", label: "Dual Collar" },
    { value: "Henley", label: "Henley" },
    { value: "High Neck", label: "High Neck" },
    { value: "Hood", label: "Hood" },
    { value: "Mandarin", label: "Mandarin" },
    { value: "Polo", label: "Polo" },
    { value: "Racerback", label: "Racerback" },
    { value: "Round", label: "Round" },
    { value: "Scoop", label: "Scoop" },
    { value: "Shawl", label: "Shawl" },
    { value: "Square", label: "Square" },
    { value: "V-neck", label: "V-neck" },
];


export const productOccasion = [
    { value: "Beach", label: "Beach" },
    { value: "Casual", label: "Casual" },
    { value: "Festive", label: "Festive" },
    { value: "Formal", label: "Formal" },
    { value: "Party", label: "Party" }
];


export const productPattern = [
    { value: "Checked", label: "Checked" },
    { value: "Colorblocked", label: "Colorblocked" },
    { value: "Dyed/ Washed", label: "Dyed/ Washed" },
    { value: "Embellished", label: "Embellished" },
    { value: "Embroidered", label: "Embroidered" },
    { value: "Printed", label: "Printed" },
    { value: "Self-Design", label: "Self-Design" },
    { value: "Solid", label: "Solid" },
    { value: "Striped", label: "Striped" },
    { value: "Woven Design", label: "Woven Design" },
    { value: "Zari Woven", label: "Zari Woven" }
];


export const productPrintOrPatterntype = [
    { value: "3D Print", label: "3D Print" },
    { value: "Abstract", label: "Abstract" },
    { value: "Animal", label: "Animal" },
    { value: "Aztec", label: "Aztec" },
    { value: "Back Print", label: "Back Print" },
    { value: "Birthday Print", label: "Birthday Print" },
    { value: "Bohemian", label: "Bohemian" },
    { value: "Botanical", label: "Botanical" },
    { value: "Brother Sister", label: "Brother Sister" },
    { value: "Buffalo Checks", label: "Buffalo Checks" },
    { value: "Camouflage", label: "Camouflage" },
    { value: "Cartoons", label: "Cartoons" },
    { value: "Checked", label: "Checked" },
    { value: "Chevron", label: "Chevron" },
    { value: "Colorblocked", label: "Colorblocked" },
    { value: "Conversational", label: "Conversational" },
    { value: "Couple Print", label: "Couple Print" },
    { value: "Cricket", label: "Cricket" },
    { value: "Ditsy Print", label: "Ditsy Print" },
    { value: "Emoji", label: "Emoji" },
    { value: "Engineered Stripes", label: "Engineered Stripes" },
    { value: "Ethnic Motif", label: "Ethnic Motif" },
    { value: "Faded", label: "Faded" },
    { value: "Fitness", label: "Fitness" },
    { value: "Floral", label: "Floral" },
    { value: "Foil Print", label: "Foil Print" },
    { value: "Football", label: "Football" },
    { value: "Friends", label: "Friends" },
    { value: "Funky Print", label: "Funky Print" },
    { value: "Game", label: "Game" },
    { value: "Geometric", label: "Geometric" },
    { value: "Gingham Checks", label: "Gingham Checks" },
    { value: "Graphic Print", label: "Graphic Print" },
    { value: "Grid Tattersail Checks", label: "Grid Tattersail Checks" },
    { value: "Heathered", label: "Heathered" },
    { value: "Holi", label: "Holi" },
    { value: "Horizontal Stripes", label: "Horizontal Stripes" },
    { value: "Houndstooth", label: "Houndstooth" },
    { value: "Independence Day/Indian Flag", label: "Independence Day/Indian Flag" },
    { value: "Mahakal", label: "Mahakal" },
    { value: "Marshmellow", label: "Marshmellow" },
    { value: "Micro Check", label: "Micro Check" },
    { value: "Micro Print", label: "Micro Print" },
    { value: "Movie/Celebrity", label: "Movie/Celebrity" },
    { value: "Newspaper Print", label: "Newspaper Print" },
    { value: "Ombre", label: "Ombre" },
    { value: "Other Sports", label: "Other Sports" },
    { value: "Paisley", label: "Paisley" },
    { value: "Pinstripes", label: "Pinstripes" },
    { value: "Placement Print", label: "Placement Print" },
    { value: "Political Print", label: "Political Print" },
    { value: "Polka Dots", label: "Polka Dots" },
    { value: "Quirky", label: "Quirky" },
    { value: "Rainbow", label: "Rainbow" },
    { value: "Religious Print", label: "Religious Print" },
    { value: "Regional", label: "Regional" },
    { value: "Rider Print", label: "Rider Print" },
    { value: "Solid", label: "Solid" },
    { value: "Superheroes", label: "Superheroes" },
    { value: "Tartan Checks", label: "Tartan Checks" },
    { value: "Tik Tok", label: "Tik Tok" },
    { value: "Tribal", label: "Tribal" },
    { value: "Typography", label: "Typography" },
    { value: "Vertical Stripes", label: "Vertical Stripes" },
    { value: "Windowpane Checks", label: "Windowpane Checks" },
    { value: "Woven Design", label: "Woven Design" }
];




