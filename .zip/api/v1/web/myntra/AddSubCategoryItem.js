/**
 * This is Contain Save router/api.
 * @author manthan Vaghasiya
 *
 */

const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { AddSubCategoryItem } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/AddSubCategoryItem:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Save AddSubCategoryItem information.
 *   description: api used for saving AddSubCategoryItem information.
 *   parameters:
 *      - in: body
 *        name: lead
 *        description: Save AddSubCategoryItem information.
 *        schema:
 *         type: object
 *         properties:
 *           AddSubCategoryItem:
 *             type: array
 *             items:
 *               type: string
 *           category:
 *               type: string
 *           subcategory:
 *               type: string
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */

const dataSchema = Joi.object({
  AddSubCategoryItem: Joi.array().items(Joi.string().required()).required().label("AddSubCategoryItem"),
  category: Joi.string().required("category"),
  subcategory: Joi.string().required("subcategory"),
});

router.post(
  "/AddSubCategoryItem",
  commonResolver.bind({
    modelService: AddSubCategoryItem,
    isRequestValidateRequired: true,
    schemaValidate: dataSchema,
  })
);

module.exports = router;
