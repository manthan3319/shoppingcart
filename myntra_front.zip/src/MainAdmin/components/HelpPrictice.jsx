import React, { useState } from "react";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import Select, { components } from 'react-select';
import { ProductSizeData, ProductColor } from "../../Content/Content";
import ReactSelect from "react-select";
import axios from 'axios';

// Checkbox option for size select
const CheckSelectSizeboxOption = (props) => {
  return (
    <components.Option {...props}>
      <input
        type="checkbox"
        checked={props.isSelected}
        onChange={() => null}
      />
      <label>{props.label}</label>
    </components.Option>
  );
};

export const HelpPrictice = () => {
  const [selectedColorOptions, setSelectedColorOptions] = useState([]);
  const [imagePreviews, setImagePreviews] = useState({});
  const [selectedSizeOptions, setSelectedSizeOptions] = useState({});

  const handleChange = (selected) => {
    setSelectedColorOptions(selected);
  };

  const handleImageUpload = (event, colorValue) => {
    const files = Array.from(event.target.files);
    if (!files.length) return;

    const imageUrls = files.map(file => ({
      file,
      url: URL.createObjectURL(file),
    }));

    setImagePreviews((prevPreviews) => ({
      ...prevPreviews,
      [colorValue]: [...(prevPreviews[colorValue] || []), ...imageUrls],
    }));
  };

  const handleCancelPreview = (colorValue, index) => {
    setImagePreviews((prevPreviews) => {
      const updatedPreviews = [...prevPreviews[colorValue]];
      updatedPreviews.splice(index, 1);
      return {
        ...prevPreviews,
        [colorValue]: updatedPreviews,
      };
    });
  };

  const handleSelectSizeChange = (selected, colorValue) => {
    setSelectedSizeOptions((prevOptions) => ({
      ...prevOptions,
      [colorValue]: selected,
    }));
  };

  const handleSubmit = async () => {
    const data = selectedColorOptions.map((option) => ({
      color: option.label,
      images: (imagePreviews[option.value] || []).map(preview => preview.file.name),
      sizes: (selectedSizeOptions[option.value] || []).map(sizeOption => sizeOption.label),
    }));
    
    console.log("Submitted Data:", data);

    // Prepare form data
    const formData = new FormData();
    selectedColorOptions.forEach((option) => {
      const files = imagePreviews[option.value] || [];
      files.forEach(({ file }) => {
        formData.append('images', file);
      });
    });

    // Upload images to the server
    try {
      const response = await axios.post('http://localhost:7000/api/v1/Myntra/UploadImages', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      console.log("Image Upload Response:", response.data);
    } catch (error) {
      console.error("Error uploading images:", error);
    }
  };

  const CustomOption = ({ innerRef, innerProps, data, isSelected }) => {
    const handleClick = (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (!isSelected) {
        setSelectedColorOptions((prevSelected) => [...prevSelected, data]);
      } else {
        setSelectedColorOptions((prevSelected) =>
          prevSelected.filter((option) => option.value !== data.value)
        );
      }
    };

    return (
      <div ref={innerRef} {...innerProps} onClick={handleClick} style={{ cursor: 'pointer' }}>
        <input
          type="checkbox"
          checked={isSelected}
          onChange={() => null}
          onClick={(event) => {
            event.preventDefault();
            event.stopPropagation();
          }}
        />
        {data.label}
      </div>
    );
  };

  return (
    <div className={`mt-[20px] bg-[#8080801c] p-[10px] rounded-[7px]`}>
      <div>
        <h3>Select Color :</h3>
        <Select
          options={ProductColor}
          isMulti
          closeMenuOnSelect={false}
          hideSelectedOptions={false}
          components={{ Option: CustomOption }}
          onChange={handleChange}
          value={selectedColorOptions}
        />
      </div>

      <p className='text-[12px] font-roboto'>Upload Images</p>
      <Tabs>
        <TabList>
          {selectedColorOptions.map((option) => (
            <Tab key={option.value}>{option.label}</Tab>
          ))}
        </TabList>

        {selectedColorOptions.map((option) => (
          <TabPanel key={option.value}>
            <h2 className='text-[12px] font-roboto text-gray-400 mb-[10px] text-center'>{`Upload images and select size for ${option.label}`}</h2>
            <div>
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={(e) => handleImageUpload(e, option.value)}
              />
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap' }}>
              {imagePreviews[option.value] &&
                imagePreviews[option.value].map((preview, index) => (
                  <div key={index} style={{ margin: '10px', position: 'relative' }}>
                    <h3>Image {index + 1}</h3>
                    <img src={preview.url} alt={`Preview ${index + 1}`} style={{ width: '100px', height: '100px' }} />
                    <button
                      onClick={() => handleCancelPreview(option.value, index)}
                      style={{
                        position: 'absolute',
                        top: '10px',
                        right: '5px',
                      }}
                      className='bg-bgmesho px-[5px] text-white rounded-[50px]'
                    >
                      <i className="fa fa-trash-o" aria-hidden="true"></i>
                    </button>
                  </div>
                ))}
            </div>
            <div className='mt-[10px]'>
              <p className='text-[12px] font-roboto text-gray-400'>Select Sizes</p>
              <div className='w-[100%] '>
                <div>
                  <ReactSelect
                    options={ProductSizeData}
                    isMulti
                    closeMenuOnSelect={false}
                    hideSelectedOptions={false}
                    components={{
                      Option: CheckSelectSizeboxOption,
                    }}
                    onChange={(selected) => handleSelectSizeChange(selected, option.value)}
                    value={selectedSizeOptions[option.value] || []}
                    className='w-[100%] outline-none'
                  />
                </div>
              </div>
            </div>
          </TabPanel>
        ))}
      </Tabs>

      <div className='category_select_from rounded-b-[12px] mt-[10px]'>
        <button type='button' className='login_owner_btn text-white' onClick={handleSubmit}>Submit Catalog</button>
      </div>
    </div>
  );
};
