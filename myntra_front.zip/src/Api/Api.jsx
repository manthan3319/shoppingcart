import { useNavigate } from "react-router-dom";
import { config } from "../config";
import axios from "axios"; // Import Axios for HTTP requests
export const fetchDataCategoryApi = async () => {
  try {
    const response = await fetch(
      `${config.apiBaseUrl}/api/v1/Myntra/getCategory`,
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      }
    );

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result = await response.json();
    return result.data.categoryData;
  } catch (error) {
    console.error("Error fetching category data:", error);
    throw error;
  }
};

export const fetchItemsWithCategoryApi = async (category) => {
  try {
    const response = await fetch(
      `${config.apiBaseUrl}/api/v1/Myntra/getIteamwithCategory`,
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ category }),
      }
    );

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result = await response.json();
    return result.data.iteamData;
  } catch (error) {
    console.error("Error fetching items with category:", error);
    throw error;
  }
};

export const GetCartItemAPI = async (cartItems, token) => {
  try {
    const response = await fetch(
      `${config.apiBaseUrl}/api/v1/Myntra/getCartIteam`,
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ cartItems, token }),
      }
    );

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result = await response.json();
    return result.data;
  } catch (error) {
    console.error("Error fetching category data:", error);
    throw error;
  }
};

export const catalogUploadApi = async (catalogData) => {
  try {
    const catalogResponse = await axios.post(
      `${config.apiBaseUrl}/api/v1/Myntra/AddCatalog`,
      catalogData
    );
    console.log("Catalog Upload Response:", catalogResponse.data);
    return catalogResponse.data;
  } catch (error) {
    console.error("Error uploading catalog data:", error);
    throw error;
  }
};

export const fetchProductDataAPI = async (
  category,
  subcategory,
  subcategoryitem,
  productId
) => {
  try {
    const response = await fetch(
      `${config.apiBaseUrl}/api/v1/Myntra/getIteamwithCondition`,
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          category,
          subcategory,
          subcategoryitem,
          productId,
        }),
      }
    );

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result = await response.json();
    return result.data.iteamData;
  } catch (error) {
    console.error("Error fetching items with category:", error);
    throw error;
  }
};

export const sendOtpAPI = async (email) => {
  try {
    const response = await axios.post(
      `${config.apiBaseUrl}/api/v1/Myntra/sendOtp`,
      email
    );
    return response;
  } catch (error) {
    console.error("otp send:", error);
    throw error;
  }
};

export const OtpverfiyAPI = async (email, otp) => {
  try {
    const response = await axios.post(
      `${config.apiBaseUrl}/api/v1/Myntra/verifyOtp`,
      {
        email: email,
        otp: otp,
      },
      {
        headers: {
          accept: "application/json",
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error("Error verifying OTP:", error);
    throw error;
  }
};

export const usercartitemAddAPI = async (token, cartItems) => {
  try {
    const response = await axios.post(
      `${config.apiBaseUrl}/api/v1/Myntra/usercartitemadd`,
      {
        token: token,
        cartItems: cartItems,
      },
      {
        headers: {
          accept: "application/json",
          "Content-Type": "application/json",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.error("Error cartItem :", error);
    throw error;
  }
};

export const CartitemRemoveAPI = async (cartid) => {
  try {
    const response = await axios.post(
      `${config.apiBaseUrl}/api/v1/Myntra/userCartItemRemove`,
      {
        cartid: cartid,
      },
      {
        headers: {
          accept: "application/json",
          "Content-Type": "application/json",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.error("Error cartItem :", error);
    throw error;
  }
};

export const AddCartItemAPI = async (token, cartItems) => {
  try {
    const response = await axios.post(
      `${config.apiBaseUrl}/api/v1/Myntra/usercartitemadd`,
      {
        token: token,
        cartItems: Array.isArray(cartItems) ? cartItems : [cartItems],
      },
      {
        headers: {
          accept: "application/json",
          "Content-Type": "application/json",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.error("Error cartItem :", error);
    throw error;
  }
};


export const updatedCartItems = async (productId, qty, size, token) => {
    try {
      const response = await axios.post(
        `${config.apiBaseUrl}/api/v1/Myntra/updateCartItemQty`,
        {
          productId : productId,
          qty: qty,
          size: size,
          token:token
        },
        {
          headers: {
            accept: "application/json",
            "Content-Type": "application/json",
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error("Error updating cart item:", error);
      throw error;
    }
};

export const userAdressAddApi = async (usertoken, name, number, pincode, address, locality,state) => {
  try {
    const response = await axios.post(
      `${config.apiBaseUrl}/api/v1/Myntra/adduseradress`,
      {
        usertoken : usertoken,
        name: name,
        number: number,
        pincode:pincode,
        address:address,
        locality:locality,
        state:state
      },
      {
        headers: {
          accept: "application/json",
          "Content-Type": "application/json",
        },
      }
    );
    return response.data;
  } catch (error) {
    console.error("Error updating cart item:", error);
    throw error;
  }
};
