import React, { useEffect, useRef, useState } from "react";
import { Navbar } from "../Navbar/Navbar";
import {
  CartitemRemoveAPI,
  GetCartItemAPI,
  updatedCartItems,
  userAdressAddApi,
} from "../../Api/Api";
import { ReplacementIcon, xletters } from "../../Images/Images";
import FadeIn from "react-fade-in";
import { createDebouncedFunction } from "../../Function/Function";
import { useNavigate } from "react-router-dom";
import "react-responsive-modal/styles.css";
import { Modal } from "react-responsive-modal";

export const AddToCart = () => {
  const navigate = useNavigate();
  const CartItems = JSON.parse(localStorage.getItem("cart")) || [];
  const token = sessionStorage.getItem("userToken");
  const [CartData, setCartData] = useState(null);
  const [TotalPrice, setTotalPrice] = useState(0);
  const [TotalMrp, setTotalMrp] = useState(0);
  const [TotalItem, setTotalItem] = useState(0);
  const [TotalQty, setTotalQty] = useState(0);
  const [adressfiled, setadressfiled] = useState(0);
  const Discount = TotalMrp - TotalPrice;
  const isDataFetchedRef = useRef(false);
  useEffect(() => {
    const fetchCartData = async () => {
      try {
        const data = await GetCartItemAPI(CartItems, token);
        if (data.cartItems && data.cartItems.length > 0) {
          setCartData(data.cartItems);
          setTotalPrice(data.totalCartPrice);
          setTotalMrp(data.totalCartMrp);
          setTotalItem(data.totalItem);
          setTotalQty(data.totalQty);

          if (token) {
            localStorage.removeItem("cart");
          }
        } else {
          console.error("No cart data found or empty response");
          setCartData([]);
        }
      } catch (error) {
        console.error("Error fetching cart data:", error);
        setCartData([]);
      }
    };

    if (!isDataFetchedRef.current && (token || CartItems.length > 0)) {
      fetchCartData();
      isDataFetchedRef.current = true;
    }
  }, [token, CartItems]);

  const handleQuantityChange = async (productId, size, change) => {
    if (!token) {
      const existingCartItems = JSON.parse(localStorage.getItem("cart")) || [];
      const updatedCartItems = existingCartItems.map((item) => {
        if (item.productId === productId && item.size === size) {
          const updatedQty = Math.max(1, item.qty + change);
          return { ...item, qty: updatedQty };
        }
        return item;
      });

      localStorage.setItem("cart", JSON.stringify(updatedCartItems));

      const updatedTotalPrice = updatedCartItems.reduce(
        (acc, item) => acc + item.productPrice * item.qty,
        0
      );
      const updatedTotalMrp = updatedCartItems.reduce(
        (acc, item) => acc + item.productMrp * item.qty,
        0
      );

      setTotalPrice(updatedTotalPrice);
      setTotalMrp(updatedTotalMrp);

      try {
        const data = await GetCartItemAPI(updatedCartItems);
        if (data.cartItems && data.cartItems.length > 0) {
          setCartData(data.cartItems);
          setTotalPrice(data.totalCartPrice);
          setTotalMrp(data.totalCartMrp);
          setTotalItem(data.totalItem);
          setTotalQty(data.totalQty);
        } else {
          console.error("No cart data found or empty response");
          setCartData([]);
        }
      } catch (error) {
        console.error("Error fetching cart data:", error);
        setCartData([]);
      }
    } else {
      try {
        const cartItem = CartData.find(
          (item) => item._doc.productId === productId && item._doc.size === size
        );
        if (cartItem) {
          const newQty = Math.max(1, cartItem._doc.qty + change);

          const updatedCartItem = await updatedCartItems(
            productId,
            newQty,
            size,
            token
          );

          const updatedCartData = await GetCartItemAPI(CartItems, token);

          if (
            updatedCartData.cartItems &&
            updatedCartData.cartItems.length > 0
          ) {
            setCartData(updatedCartData.cartItems);
            setTotalPrice(updatedCartData.totalCartPrice);
            setTotalMrp(updatedCartData.totalCartMrp);
            setTotalItem(updatedCartData.totalItem);
            setTotalQty(updatedCartData.totalQty);
          } else {
            console.error("No cart data found or empty response");
            setCartData([]);
          }
        } else {
          console.error("Cart item not found for update");
        }
      } catch (error) {
        console.error(
          "Error updating cart item:",
          error.response?.data || error.message
        );
      }
    }
  };

  const debouncedHandleQuantityChange = (productId, size, change) => {
    createDebouncedFunction(handleQuantityChange, 300)(productId, size, change);
  };

  const handleDelete = async (productId, size) => {
    if (!token) {
      handleDeleteWithCookie(productId, size);
    } else {
      try {
        const cartItem = CartData.find(
          (item) => item.productId === productId && item.size === size
        );
        if (cartItem) {
          console.log("cartItem._id", cartItem.cartId);
          await CartitemRemoveAPI(cartItem.cartId);

          const updatedCartData = await GetCartItemAPI(CartItems, token);

          if (
            updatedCartData.cartItems &&
            updatedCartData.cartItems.length > 0
          ) {
            setCartData(updatedCartData.cartItems);
            setTotalPrice(updatedCartData.totalCartPrice);
            setTotalMrp(updatedCartData.totalCartMrp);
            setTotalItem(updatedCartData.totalItem);
            setTotalQty(updatedCartData.totalQty);
          } else {
            console.error("No cart data found or empty response");
            setCartData([]);
          }
        } else {
          console.error("Cart item not found for deletion");
        }
      } catch (error) {
        console.error("Error removing cart item from server:", error);
      }
    }
  };

  const handleDeleteWithCookie = async (productId, size) => {
    const existingCartItems = JSON.parse(localStorage.getItem("cart")) || [];
    const updatedCartItems = existingCartItems.filter(
      (item) => !(item.productId === productId && item.size === size)
    );
    localStorage.setItem("cart", JSON.stringify(updatedCartItems));

    const updatedTotalPrice = updatedCartItems.reduce(
      (acc, item) => acc + item.productPrice * item.qty,
      0
    );
    const updatedTotalMrp = updatedCartItems.reduce(
      (acc, item) => acc + item.productMrp * item.qty,
      0
    );

    setTotalPrice(updatedTotalPrice);
    setTotalMrp(updatedTotalMrp);

    try {
      const data = await GetCartItemAPI(updatedCartItems);
      if (data.cartItems && data.cartItems.length > 0) {
        setCartData(data.cartItems);
        setTotalPrice(data.totalCartPrice);
        setTotalMrp(data.totalCartMrp);
        setTotalItem(data.totalItem);
        setTotalQty(data.totalQty);
      } else {
        console.error("No cart data found or empty response");
        setCartData([]);
      }
    } catch (error) {
      console.error("Error fetching cart data:", error);
      setCartData([]);
    }
  };

  const handlePlaceOrder = async () => {
    if (!token) {
      navigate("/userlogin");
    } else {
      setadressfiled(1);
    }
  };

  const [open, setOpen] = useState(false);
  const onOpenModal = () => setOpen(true);
  const onCloseModal = () => setOpen(false);
  const [name, setName] = useState("");
  const [number, setNumber] = useState("");
  const [pincode, setPincode] = useState("");
  const [address, setAddress] = useState("");
  const [locality, setLocality] = useState("");
  const [state, setState] = useState("");
  const customModalStyles = {
    modal: {
      maxWidth: "441px",
      width: "90%",
      borderRadius: "5px",
      padding: "0px",
    },
  };

  const handleAddAddress = async () => {
    try {
      const addAdressData = await userAdressAddApi(token, name, number, pincode, address, locality, state);
      console.log("addAdressData",addAdressData)
      onCloseModal();
    } catch (error) {
      console.error("Address not Add");
    }
  };

  
  return (
    <div>
      <div className="hadline_bag flex justify-center my-[30px] gap-[10px]">
        <div
          className={`${
            adressfiled === 0
              ? "text-[#20bd99] border-b-[#20bd99] border-b-[2px]"
              : "text-black border-b-[0px]"
          }`}
          onClick={() => setadressfiled(0)}
        >
          BAG
        </div>
        <div>-----------------</div>
        <div
          className={`${
            adressfiled === 1
              ? "text-[#20bd99] border-b-[#20bd99] border-b-[2px]"
              : "text-black border-b-[0px]"
          }`}
        >
          ADDRESS
        </div>
        <div>-----------------</div>
        <div>PAYMENT</div>
      </div>
      <div className="lg:max-w-[1000px] mx-auto m-0 px-[50px] mt-[20px] ">
        {CartData ? (
          <div className="flex lg:flex-row gap-x-[15px] justify-between">
            <div className="w-[60%]">
              <div className={adressfiled === 0 ? "block" : "hidden"}>
                {CartData.map((item) => (
                  <FadeIn key={`${item.productId}-${item.size}`}>
                    <div className="flex gap-x-[10px] border-[#eaeaec] border-[1px] p-[5px] mb-[10px] relative">
                      <div className="absolute right-[10px] top-[10px]">
                        <img
                          src={xletters}
                          className="w-[15px] cursor-pointer"
                          onClick={() =>
                            handleDelete(item.productId, item.size)
                          }
                          alt="delete"
                        />
                      </div>
                      <div className="w-[27%]">
                        <img
                          src={`http://localhost:7000/productimg/${item.image}`}
                          alt={item.productName}
                          className="w-[150px] h-[160px]"
                        />
                      </div>
                      <div className="w-[87%]">
                        <p className="text-[#7e818c] text-[13px] font-roboto">
                          {item.category} : {item.subcategory} :{" "}
                          {item.subcategoryitem}
                        </p>
                        <h2 className="text-black text-[15px] font-roboto font-semibold mt-[7px]">
                          {item.productName}
                        </h2>
                        <p className="text-[#7e818c] text-[14px]">
                          {item.ShortDescription}
                        </p>
                        <div className="flex flex-row gap-[10px] mt-[7px]">
                          <p className="px-[10px] rounded-[6px] bg-[#f5f5f6] text-[15px] font-roboto font-medium">
                            Size: {item.productSize}
                          </p>
                          <div className="flex items-center  rounded-[6px] bg-[#f5f5f6] text-[15px] font-roboto font-medium">
                            <button
                              className="px-[10px] bg-[#eaeaec] rounded-[6px]"
                              onClick={() => {
                                if (token) {
                                  // Token is present, use the token-based condition
                                  debouncedHandleQuantityChange(
                                    item._doc.productId,
                                    item.productSize,
                                    -1
                                  );
                                } else {
                                  // Token is not present, use the no-token condition
                                  debouncedHandleQuantityChange(
                                    item.productId,
                                    item.size,
                                    -1
                                  );
                                }
                              }}
                            >
                              -
                            </button>
                            <p className="px-[10px]">{item.qty}</p>
                            {item.qty === 10 ? (
                              <button
                                className="px-[10px] bg-[#eaeaec] rounded-[6px]"
                                onClick={() => {
                                  if (token) {
                                    // Token is present, use the token-based condition
                                    debouncedHandleQuantityChange(
                                      item._doc.productId,
                                      item.productSize,
                                      1
                                    );
                                  } else {
                                    // Token is not present, use the no-token condition
                                    debouncedHandleQuantityChange(
                                      item.productId,
                                      item.size,
                                      1
                                    );
                                  }
                                }}
                              >
                                +
                              </button>
                            ) : (
                              <button
                                className="px-[10px] bg-[#eaeaec] rounded-[6px]"
                                onClick={() => {
                                  if (token) {
                                    // Token is present, use the token-based condition
                                    debouncedHandleQuantityChange(
                                      item._doc.productId,
                                      item.productSize,
                                      1
                                    );
                                  } else {
                                    debouncedHandleQuantityChange(
                                      item.productId,
                                      item.size,
                                      1
                                    );
                                  }
                                }}
                              >
                                +
                              </button>
                            )}
                          </div>
                        </div>
                        <div className="flex mt-[10px] gap-[7px] items-center">
                          <p className="text-[15px] font-roboto font-medium">
                            ₹ {item.productPrice}
                          </p>
                          <p className="text-[13px] font-roboto text-[#94969f]">
                            <del>₹{item.productMrp}</del>
                          </p>
                        </div>
                        <p className="text-[12px] mt-[10px] font-roboto flex">
                          <span>
                            <img
                              src={ReplacementIcon}
                              className="w-[15px] mr-[5px]"
                              alt="replacement"
                            />
                          </span>{" "}
                          <span className="font-semibold">7 days</span>{" "}
                          Replacement Policy{" "}
                        </p>
                      </div>
                    </div>
                  </FadeIn>
                ))}
              </div>

              <div className={adressfiled === 1 ? "block" : "hidden"}>
                <div className="address flex justify-between items-center border-b-[1px] pb-[10px]">
                  <div>
                    <h1 className="font-roboto text-[17px]">
                      Select Delivery Address
                    </h1>
                  </div>
                  <div>
                    <button
                      onClick={onOpenModal}
                      className="font-roboto text-[14px] border-[1px] py-[10px] px-[20px] rounded-[5px] border-black"
                    >
                      ADD NEW ADDRESS
                    </button>

                    <div>
                      <Modal
                        open={open}
                        onClose={onCloseModal}
                        center
                        styles={customModalStyles}
                      >
                        <div className="p-[20px]  border-b-[1px]">
                          <h1 className="font-roboto font-semibold text-[#535766] text-[14px]">
                            ADD NEW ADDRESS
                          </h1>
                        </div>
                        <div className="mt-[13px] px-[20px]">
                          <h2 className="my-[5px] text-[11px] text-[#535766] font-semibold font-roboto">
                            CONTACT DETAILS
                          </h2>
                          <div>
                            <input
                              type="text"
                              placeholder="Name*"
                              className="w-[100%] border-[#d4d5d9] border-[1px] px-[5px] py-[10px] outline-none rounded-[5px]
                              text-[12px] font-roboto mb-[10px]"
                              onChange={(e) => setName(e.target.value)}
                            />

                            <input
                              type="number"
                              placeholder="Mobile No*"
                              className="w-[100%] border-[#d4d5d9] border-[1px] px-[5px] py-[10px] outline-none rounded-[5px]
                              text-[12px] font-roboto mb-[10px]"
                              onChange={(e) => setNumber(e.target.value)}
                            />
                          </div>
                        </div>

                        <div className="mt-[20px] px-[20px]">
                          <h2 className="my-[5px] text-[11px] font-roboto font-semibold ">
                            ADDRESS
                          </h2>
                          <div>
                            <input
                              type="number"
                              placeholder="Pin Code*"
                              className="w-[100%] border-[#d4d5d9] border-[1px] px-[5px] py-[10px] outline-none rounded-[5px]
                              text-[12px] font-roboto mb-[10px]"
                              onChange={(e) => setPincode(e.target.value)}
                            />

                            <input
                              type="text"
                              placeholder="Address (House No, Building, Street, Area)*"
                              className="w-[100%] border-[#d4d5d9] border-[1px] px-[5px] py-[10px] outline-none rounded-[5px]
                              text-[12px] font-roboto mb-[10px]"
                              onChange={(e) => setAddress(e.target.value)}
                            />

                            <input
                              type="text"
                              placeholder="Locality / Town*"
                              className="w-[100%] border-[#d4d5d9] border-[1px] px-[5px] py-[10px] outline-none rounded-[5px]
                              text-[12px] font-roboto mb-[10px]"
                              onChange={(e) => setLocality(e.target.value)}
                            />

                            <input
                              type="text"
                              placeholder="State*"
                              className="w-[100%] border-[#d4d5d9] border-[1px] px-[5px] py-[10px] outline-none rounded-[5px]
                              text-[12px] font-roboto mb-[10px]"
                              onChange={(e) => setState(e.target.value)}
                            />
                          </div>
                        </div>

                        <div className="w-[100%] inline-block text-center mt-[20px]">
                          <button className="bg-bgmesho w-[100%] py-[10px] text-white font-semibold font-roboto" onClick={handleAddAddress}>
                            ADD ADDRESS
                          </button>
                        </div>
                      </Modal>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="w-[30%] fixed right-[147px]">
              <div className="border-[#eaeaec] border-[1px] ">
                <div className="border-b-[1px] p-[10px]">
                  <h1 className="text-[#0daaee] text-[17px] font-roboto font-bold">
                    PRICE DETAILS
                  </h1>
                </div>
                <div className="p-[10px]">
                  <div className="flex flex-row justify-between mb-[7px]">
                    <p className="text-[16px] font-roboto">
                      Price ({TotalItem} item)
                    </p>
                    <p className="text-[16px] font-roboto">₹{TotalMrp}</p>
                  </div>
                  <div className="flex flex-row justify-between mb-[7px]">
                    <p className="text-[16px] font-roboto">Total Qty</p>
                    <p className="text-[16px] font-roboto">{TotalQty}</p>
                  </div>
                  <div className="flex flex-row justify-between mb-[7px]">
                    <p className="text-[16px] font-roboto">Discount</p>
                    <p className="text-[16px] font-roboto text-[#0be34d]">
                      -₹{Discount}
                    </p>
                  </div>
                  <div className="flex flex-row justify-between mb-[7px]">
                    <p className="text-[16px] font-roboto">Delivery Charges</p>
                    <p className="text-[16px] font-roboto text-[#0be34d]">
                      Free
                    </p>
                  </div>
                  <div className="flex flex-row justify-between my-[15px] py-[10px] border-t-[1px] border-b-[1px]">
                    <p className="text-[16px] font-roboto font-bold">
                      Total Amount
                    </p>
                    <p className="text-[16px] font-roboto font-bold">
                      ₹{TotalPrice}
                    </p>
                  </div>
                  <p className="text-[15px] font-roboto text-[#0be34d]">
                    You will save ₹{Discount} on this order
                  </p>
                </div>
              </div>
              <div>
                {adressfiled === 1 ? (
                  <button
                    className="bg-bgmesho w-[100%] py-[8px] text-white font-roboto font-extrabold"
                    onClick={handlePlaceOrder}
                  >
                    continue
                  </button>
                ) : (
                  <button
                    className="bg-bgmesho w-[100%] py-[8px] text-white font-roboto font-extrabold"
                    onClick={handlePlaceOrder}
                  >
                    PLACE ORDER
                  </button>
                )}
              </div>
            </div>
          </div>
        ) : (
          <p>Loading cart data...</p>
        )}
      </div>
    </div>
  );
};
