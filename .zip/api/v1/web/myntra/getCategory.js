/**
 * This is Contain Save router/api.
 * @author manthan Vaghasiya
 *
 */

const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { getCategory } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/getCategory:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Save Category information.
 *   description: api used for saving category information.
 *   parameters:
 *      - in: body
 *        name: lead
 *        description: Save category information.
 *        schema:
 *         type: object
 *         properties:
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */


router.post(
  "/getCategory",
  commonResolver.bind({
    modelService: getCategory,
  })
);

module.exports = router;
