const contractorModel = require("./contractor");
const mainownerModel = require("./mainowner");
const categoryModel = require("./category");
const subcategoryModel = require("./subcategory");
const subcategoryItemModel = require("./subcategoryitem");
const brandModel = require("./brand");
const productModel = require("./product");
const UserOtpModel =require("./userotp");
const UserModel = require("./user");
const cartItemModel = require("./cartitem");
const useraddressModel = require("./useraddress");
module.exports = {
  contractorModel,
  mainownerModel,
  categoryModel,
  subcategoryModel,
  subcategoryItemModel,
  brandModel,
  productModel,
  UserOtpModel,
  UserModel,
  cartItemModel,
  useraddressModel
};
