import React from 'react';
import { NavbarMenu } from '../../Content/Content';
import { logo } from '../../Images/Images';
import { Link, useNavigate } from 'react-router-dom';

export const Navbar = () => {
    const navigate = useNavigate();
    const CartItems = JSON.parse(localStorage.getItem('cart')) || [];
    const handleCategoryClick = (category, subcategory, item, e) => {
        e.stopPropagation();
        let path = `/${category}`;
        if (subcategory) path += `/${subcategory}`;
        if (item) path += `/${item}`;
        navigate(path);
    };

    return (
        <div className='lg:max-w-[1440px] mx-auto lg:px-[50px] bg-white sticky w-full top-0 !z-[9999] navbarsection'>
            <div className='flex navbar-item'>
                <div className='flex items-center w-[50%] gap-[30px]'>
                    <div>
                        <Link to="/"><img src={logo} alt='logo' className='w-[52px] filter_logo' /> </Link>
                    </div>
                    <div>
                        <nav>
                            <ul className='navbar-menu flex gap-[12px]'>
                                {NavbarMenu.map((category, index) => (
                                    <li key={index}
                                        className={`group font-roboto text-[14px] font-medium py-[25px] border-transparent border-b-2 px-[8px]
                                        ${category.title === "MEN" ? "hover:border-b-[#ee5f73]" :
                                                category.title === "Women" ? "hover:border-b-[#fb56c1]" :
                                                    category.title === "Kids" ? "hover:border-b-[#f26a10]" :
                                                        category.title === "Home & Living" ? "hover:border-b-[#f2c210]" :
                                                            category.title === "Beauty" ? "hover:border-b-[#0db7af]" :
                                                                category.title === "Studio" ? "hover:border-b-[#ff3f6c]" : ""}`}
                                        onClick={(e) => handleCategoryClick(category.title, null, null, e)}>
                                        {category.title}
                                        {category.subcategories && (
                                            <div className='hidden group-hover:block group-hover:absolute bg-white rounded-b-[5px] dropdown-menu left-0 mt-[27px]'>
                                                <div className='dropdown-menu_list px-[30px] py-[20px]'>
                                                    {category.subcategories.map((subcategory, subIndex) => (
                                                        <div key={subIndex} className='dropdown-subcategory'>
                                                            <div className={`subcategory-title font-semibold text-[13px] font-roboto mb-[6px]
                                                                ${category.title === "MEN" ? "text-[#ee5f73]" :
                                                                    category.title === "Women" ? "text-[#fb56c1]" :
                                                                        category.title === "Kids" ? "text-[#f26a10]" :
                                                                            category.title === "Home & Living" ? "text-[#f2c210]" :
                                                                                category.title === "Beauty" ? "text-[#0db7af]" :
                                                                                    category.title === "Studio" ? "text-[#ff3f6c]" : ""}`}
                                                                onClick={(e) => handleCategoryClick(category.title, subcategory.title, null, e)}>
                                                                {subcategory.title}
                                                            </div>
                                                            {subcategory.iteam && (
                                                                <ul className='subcategory-items'>
                                                                    {subcategory.iteam.map((item, itemIndex) => (
                                                                        <li key={itemIndex}
                                                                            className='font-roboto text-[14px] font-extralight text-[gray] hover:text-black mb-[3px]'
                                                                            onClick={(e) => handleCategoryClick(category.title, subcategory.title, item, e)}>
                                                                            {item}
                                                                        </li>
                                                                    ))}
                                                                </ul>
                                                            )}
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        )}
                                    </li>
                                ))}
                            </ul>
                        </nav>
                    </div>
                </div>

                <div className='flex gap-x-[40px] w-[50%] py-[15px]'>
                    <div className='flex gap-[10px] w-[70%] rounded-[3px] bg-[#EEEEEF] items-center px-[10px]'>
                        <div>
                            <i className="fa fa-search" aria-hidden="true"></i>
                        </div>
                        <div className='w-[84%]'>
                            <input type='text' placeholder='Search for products, brands and more' className='outline-none bg-[#EEEEEF] py-[2px] text-[13px] w-[100%]' />
                        </div>
                    </div>

                    <div className='flex gap-[15px] items-center'>
                        <div className='flex flex-col items-center'>
                            <span><i className="fa fa-user" aria-hidden="true"></i></span>
                            <p className='font-roboto text-[13px]'>Profile</p>
                        </div>

                        <div className='flex flex-col items-center'>
                            <span><i className="fa fa-heart-o" aria-hidden="true"></i></span>
                            <p className='font-roboto text-[13px]'>Wishlist</p>
                        </div>

                        <div className='flex flex-col items-center'>
                            <Link to="/bag">
                                <span className='relative'>
                                    <i className="fa fa-shopping-bag" aria-hidden="true"></i>
                                    <span className='absolute bg-[#0be34d] w-[20px] h-[20px] text-center rounded-[50px] text-white font-roboto font-semibold right-[-16px] text-[14px]'>{CartItems.length}</span>
                                </span>
                                <p className='font-roboto text-[13px]'>Bag</p>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
