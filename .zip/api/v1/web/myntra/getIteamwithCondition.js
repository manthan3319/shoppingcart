/**
 * This is Contain Save router/api.
 * @author manthan Vaghasiya
 *
 */

const { Joi } = require("../../../../utilities/schemaValidate");
const { Router } = require("express");
const commonResolver = require("../../../../utilities/commonResolver");
const { getIteamwithCondition } = require("../../../../services/myntra/myntra");
const router = new Router();

/**
 * @swagger
 * /api/v1/Myntra/getIteamwithCondition:
 *  post:
 *   tags: ["Myntra"]
 *   summary: Save getIteamwithCondition information.
 *   description: api used for saving getIteamwithCondition information.
 *   parameters:
 *      - in: body
 *        name: lead
 *        description: Save getIteamwithCondition information.
 *        schema:
 *         type: object
 *         properties:
 *           category:
 *             type: string
 *           subcategory:
 *             type: string
 *           subcategoryitem:
 *             type: string
 *           productId:
 *             type: string
 *            
 *   responses:
 *    "200":
 *     description: success
 *    "400":
 *     description: fail
 */



router.post(
  "/getIteamwithCondition",
  commonResolver.bind({
    modelService: getIteamwithCondition,
  })
);

module.exports = router;
