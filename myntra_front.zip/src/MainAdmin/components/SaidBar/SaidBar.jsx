import React from 'react';
import { MainAdminSaidbar } from '../../../Content/Content';
import { Link } from 'react-router-dom';
import { logo2 } from '../../../Images/Images';
import { useNavigate } from 'react-router-dom';
export const SaidBar = () => {
    const navigate = useNavigate();
    
    const logout = () => {
        sessionStorage.removeItem('owner');
        navigate("/owner")
    };

    return (
        <div>
            <div className='saidbar border-r-[2px] border-[#f44a0080]  sticky'>
                <div className='mb-[10px] border-b-[2px] border-white py-[10px] px-[10px]'>
                   <Link to="/ownerPanel"> <img src={logo2} className='w-[130px]' alt='Logo' /></Link>
                </div>
                <div className='py-[10px] px-[10px]'>
                    <ul>
                        {MainAdminSaidbar.map((item) => (
                            <li key={item.id} className='mb-[8px]'>
                                <Link to={`/ownerPanel/?${item.Link}`} className='text-white font-roboto p-[10px] bg-bgmesho w-[100%] rounded-[5px] flex flex-row items-center gap-[10px]'>
                                    <span><img src={item.logo} className='w-[30px]' alt='Logo' /></span>{item.Name}
                                </Link>
                            </li>
                        ))}
                    </ul>

                    <div className='absolute bottom-0 w-[90%]'>
                        <button onClick={logout} className='bg-bgmesho font-roboto text-center p-[10px] text-white rounded-t-[7px] inline-block w-[100%]'>Logout</button>
                    </div>
                </div>
            </div>
        </div>
    );
};
