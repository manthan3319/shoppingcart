import React from 'react';
import { Link } from 'react-router-dom';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import debounce from 'lodash/debounce';
import FadeIn from 'react-fade-in';

const CustomHeader = ({ text, link }) => {
  return (
    <div className='border-b-[1px] border-[#f41cb2] bg-[#f44a0080] p-[10px] rounded-t-[10px]'>
      <p className='flex gap-[10px] font-roboto text-[15px]'>
        <Link to={link}>HOME</Link>
        <span><i className="fa fa-angle-right" aria-hidden="true"></i></span>
        {text}
      </p>
    </div>
  );
};

const useTokenRequire = (pathname) => {
  const navigate = useNavigate();

  useEffect(() => {
    const token = sessionStorage.getItem('owner');
    if (!token) {
      navigate(pathname);
    }
  }, [navigate, pathname]);
};


const FNselectFiledOption = ({ name, data, value, onChange }) => {
  return (
    <fieldset className='w-[50%] border-[1px] px-[10px] py-[3px] rounded-[5px] border-[gray] font-roboto text-[13px]'>
      <legend>{name}</legend>
      <select name={name} value={value} onChange={onChange} className='outline-none w-[100%] text-[13px] font-roboto p-[5px]'>
        {data.map((option) => (
          <option key={option.value} value={option.value}>{option.label}</option>
        ))}
      </select>
    </fieldset>
  );
};

const ProductCard = ({ product, settings }) => {
  const firstColor = product.color[0];
  const images = firstColor.images;

  return (

    <div className='product_card w-[17.5%]'>
      <FadeIn>
        <Link to={`/productview/?id=${product._id}`}>
          <div className='h-[280px] w-full inline-block relative overflow-hidden'>
            <Slider {...settings}>
              {images.map((image, imgIndex) => (
                <div key={imgIndex}>
                  <img src={`http://localhost:7000/productimg/${image}`} alt={`product img ${imgIndex}`} className='w-full h-full object-cover' />
                </div>
              ))}
            </Slider>
          </div>
          <div className='bg-[#fff] p-[5px] product_details_card rounded-b-[7px]'>
            <h1 className='text-[15px] font-roboto font-bold'>{product.productName}</h1>
            <p className='text-[12px] font-roboto text-[#535766]'>{product.ShortDescription}</p>
            <div className='flex gap-x-[7px] mt-[5px]'>
              <p className='text-[13px] font-roboto'><b>Rs.{product.productPrice}</b></p>
              <p className='text-[12px] text-[#7e818c]'><del>Rs.{product.productMrp}</del></p>
            </div>
          </div>
        </Link>
      </FadeIn>
    </div>
  );
};

const ProductDetailSection = ({ label, value }) => (
  <div className='border-b-[1px] pb-[10px] w-[100%]'>
    <p className='text-[#7e818c] text-[14px] font-roboto'>{label}</p>
    <p className='text-[16px] font-roboto mt-[2px]'>{value}</p>
  </div>
);

const createDebouncedFunction = (func, wait) => {
  return debounce(func, wait);
};

export { CustomHeader, useTokenRequire, FNselectFiledOption, ProductCard, ProductDetailSection, createDebouncedFunction };
