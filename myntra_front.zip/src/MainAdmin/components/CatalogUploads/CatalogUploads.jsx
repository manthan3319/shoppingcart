import React, { useState, useEffect } from 'react';
import { CustomHeader } from '../../../Function/Function';
import {
    fetchDataCategoryApi,
    fetchItemsWithCategoryApi,
    catalogUploadApi
} from '../../../Api/Api';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {
    ProductColor,
    ProductSizeData,
    productFabric,
    productSleeveStyling,
    productSleeveLength,
    productFitShape,
    productNeck,
    productOccasion,
    productPattern,
    productPrintOrPatterntype
} from '../../../Content/Content';
import { FNselectFiledOption } from '../../../Function/Function';
import Select, { components } from 'react-select';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ReactSelect from "react-select";
import axios from 'axios';

export const CatalogUploads = () => {
    const [categoryData, setCategoryData] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('');
    const [selectedSubCategory, setSelectedSubCategory] = useState('');
    const [selectedItem, setSelectedItem] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [itemData, setItemData] = useState([]);
    const [selectedSizes, setSelectedSizes] = useState([]);


    useEffect(() => {
        const fetchData = async () => {
            try {
                const data = await fetchDataCategoryApi();
                setCategoryData(data);
            } catch (error) {
                setError('Error fetching category data.');
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

    const handleCategorySelect = async (event) => {
        const selectedCategory = event.target.value;
        setSelectedCategory(selectedCategory);

        if (selectedCategory) {
            try {
                const data = await fetchItemsWithCategoryApi(selectedCategory);
                setItemData(data);
                setSelectedSubCategory('');
            } catch (error) {
                setError('Error fetching item data.');
            }
        }
    };

    const handleSubcategorySelect = (event) => {
        const selectedSubCategory = event.target.value;
        setSelectedSubCategory(selectedSubCategory);
        setSelectedItem('');
    };

    const handleItemSelect = (event) => {
        const selectedItem = event.target.value;
        setSelectedItem(selectedItem);
    };

    //color seclect and photo upload images
    const [selectedColorOptions, setSelectedColorOptions] = useState([]);
    const [imagePreviews, setImagePreviews] = useState({});
    // console.log("selectedColorOptions", selectedColorOptions);
    const handleChange = (selected) => {
        setSelectedColorOptions(selected);
    };

    const handleImageUpload = (event, colorValue) => {
        const files = Array.from(event.target.files);
        if (!files.length) return;

        const imageUrls = files.map(file => ({
            file,
            url: URL.createObjectURL(file),
        }));

        setImagePreviews((prevPreviews) => ({
            ...prevPreviews,
            [colorValue]: [...(prevPreviews[colorValue] || []), ...imageUrls],
        }));
    };

    const handleCancelPreview = (colorValue, index) => {
        setImagePreviews((prevPreviews) => {
            const updatedPreviews = [...prevPreviews[colorValue]];
            updatedPreviews.splice(index, 1);
            return {
                ...prevPreviews,
                [colorValue]: updatedPreviews,
            };
        });
    };

    const CustomOption = ({ innerRef, innerProps, data, isSelected }) => {
        const handleClick = (event) => {
            event.preventDefault();
            event.stopPropagation();
            if (!isSelected) {
                setSelectedColorOptions((prevSelected) => [...prevSelected, data]);
            } else {
                setSelectedColorOptions((prevSelected) =>
                    prevSelected.filter((option) => option.value !== data.value)
                );
            }
        };

        return (
            <div ref={innerRef} {...innerProps} onClick={handleClick} style={{ cursor: 'pointer' }}>
                <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={() => null}
                    onClick={(event) => {
                        event.preventDefault();
                        event.stopPropagation();
                    }}
                />
                {data.label}
            </div>
        );
    };

    //select size code
    const [selectedSizeOptions, setSelectedSizeOptions] = useState([]);
    const handleSelectSizeChange = (selected, colorValue) => {
        setSelectedSizeOptions((prevOptions) => ({
            ...prevOptions,
            [colorValue]: selected,
        }));
    };
    const CheckSelectSizeboxOption = (props) => {
        return (
            <components.Option {...props}>
                <input
                    type="checkbox"
                    checked={props.isSelected}
                    onChange={() => null}
                />
                <label>{props.label}</label>
            </components.Option>
        );
    };


    //fromdata
    const [selectedFabric, setSelectedFabric] = useState('');
    const [selectedSleeveStyling, setSelectedSleeveStyling] = useState('');
    const [selectedSleeveLength, setSelectedSleeveLength] = useState('');
    const [selectedfitshape, setselectedfitshape] = useState('');
    const [selectedNeck, setselectedNeck] = useState('');
    const [selectedOccasion, setselectedOccasion] = useState('');
    const [selectedPattern, setselectedPattern] = useState('');
    const [selectedPrintOrPatternType, setselectedPrintOrPatternType] = useState('');
    const [selectedProductname, setselectedProductname] = useState('');
    const [selectedShortDescription, setselectedShortDescription] = useState('');
    const [selecteprice, setprice] = useState('');
    const [selectemrp, setmrp] = useState('');
    const [selectdescription, setselectdescription] = useState('');
    const token = sessionStorage.getItem('owner');
    console.log("token",token);
    const handleselectepriceChange = (e) => {
        setprice(e.target.value);
    };

    const handleselectemrpChange = (e) => {
        setmrp(e.target.value);
    };

    const handleselectdescriptionChange = (e) => {
        setselectdescription(e.target.value);
    };

    const handleFabricChange = (e) => {
        setSelectedFabric(e.target.value);
    };

    const selectedSleeveStylingChange = (e) => {
        setSelectedSleeveStyling(e.target.value);
    };

    const handleSleeveLengthChange = (e) => {
        setSelectedSleeveLength(e.target.value);
    };

    const selectedfitshapeChange = (e) => {
        setselectedfitshape(e.target.value);
    };

    const selectedNeckChange = (e) => {
        setselectedNeck(e.target.value);
    };

    const selectedselectedOccasionChange = (e) => {
        setselectedOccasion(e.target.value);
    };

    const selectedPatternChange = (e) => {
        setselectedPattern(e.target.value);
    };

    const selectedPrintOrPatternTypeChange = (e) => {
        setselectedPrintOrPatternType(e.target.value);
    };

    const handleProductNameChange = (e) => {
        setselectedProductname(e.target.value);
    };

    const handleselectedShortDescriptionChange = (e) => {
        setselectedShortDescription(e.target.value);
    };


    const SubmitCatalog = async () => {
        // Prepare color data with uploaded image names and sizes
        const colorImageSizeData = selectedColorOptions.map((option) => ({
            color: option.label,
            images: (imagePreviews[option.value] || []).map(preview => preview.file.name),
            sizes: (selectedSizeOptions[option.value] || []).map(sizeOption => sizeOption.label),
        }));

        // console.log("Submitted Data:", colorImageSizeData);

        // Prepare form data for image upload
        const formData = new FormData();
        selectedColorOptions.forEach((option) => {
            const files = imagePreviews[option.value] || [];
            files.forEach(({ file }) => {
                formData.append('images', file);
            });
        });


        // Upload images to the server
        try {
            const response = await axios.post('http://localhost:7000/api/v1/Myntra/UploadImages', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            // console.log("Image Upload Response:", response.data);
        } catch (error) {
            // console.error("Error uploading images:", error);
        }


        const catalogData = {
            category: selectedCategory,
            subcategory: selectedSubCategory,
            subcategoryitem: selectedItem,
            productName: selectedProductname,
            ShortDescription: selectedShortDescription,
            productPrice: selecteprice,
            productMrp: selectemrp,
            color: colorImageSizeData,
            Fabric: selectedFabric,
            sleeveStyling: selectedSleeveStyling,
            sleeveLength: selectedSleeveLength,
            fitShape: selectedfitshape,
            Neck: selectedNeck,
            occasion: selectedOccasion,
            pattern: selectedPattern,
            printOrpattern: selectedPrintOrPatternType,
            Description: selectdescription,
            token:token
        };

        // console.log("Catalog Data:", catalogData);
        try {
            const catalogResponse = await catalogUploadApi(catalogData);
            if (catalogResponse.statusCode === 200) {
                toast.success("Catalog added successfully", {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                    theme: "colored"
                });

                // setSelectedCategory('');
                // setSelectedSubCategory('');
                // setSelectedItem('');
                // setselectedProductname('');
                // setselectedShortDescription('');
                // setprice('');
                // setmrp('');
                // setSelectedColorOptions([]);
                // setImagePreviews({});
                // setSelectedSizeOptions({});
                // setSelectedFabric('');
                // setSelectedSleeveStyling('');
                // setSelectedSleeveLength('');
                // setselectedfitshape('');
                // setselectedNeck('');
                // setselectedOccasion('');
                // setselectedPattern('');
                // setselectedPrintOrPatternType('');
                // setselectdescription('');
            }
        } catch (error) {
            toast.error("Catalog Not added", {
                position: "top-right",
                autoClose: 5000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "colored"
            });
        }
    };



    return (
        <div>
            <div>
                <CustomHeader text="CatalogUploads" link="/ownerPanel" />
            </div>

            <div className='mt-[30px] flex flex-row gap-[20px]'>
                <div className='w-[40%]'>
                    {loading ? (
                        <div>Loading...</div>
                    ) : error ? (
                        <div>Error: {error}</div>
                    ) : (
                        <div>
                            <div className={`category_select_from rounded-t-[10px] ${selectedSubCategory === "" ? "hidden" : "block"}`}>
                                {selectedCategory && (
                                    <div>
                                        <p className='text-[#f25511] font-roboto font-medium'>Selected Categories</p>
                                        <p>{selectedCategory} : {selectedSubCategory} : {selectedItem} </p>
                                    </div>
                                )}
                            </div>

                            <div className={`category_select_from mt-[10px] ${selectedCategory === "" ? "rounded-t-[10px]" : ""}
                            ${selectedCategory === "" ? "rounded-b-[10px]" : ""}`}>
                                <p className={`text-[12px] font-roboto ${selectedCategory === "" ? "hidden" : "block"}`}>Select Category</p>
                                <select value={selectedCategory} onChange={handleCategorySelect}
                                    className='outline-none w-[100%]'>
                                    <option value="" disabled>Select a category</option>
                                    {categoryData.map((category) => (
                                        <option key={category._id} value={category.category}>
                                            {category.category}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            {selectedCategory && (
                                <div className='category_select_from mt-[10px]'>
                                    <p className={`text-[12px] font-roboto ${selectedSubCategory === "" ? "hidden" : "block"} 
                                    ${selectedItem === "" ? "rounded-b-[10px]" : ""}`}>Select SubCategory</p>
                                    {itemData.length > 0 ? (
                                        <select value={selectedSubCategory} onChange={handleSubcategorySelect}
                                            className='outline-none w-[100%]'>
                                            <option value="" disabled>Select a subcategory</option>
                                            {itemData.map((item) => (
                                                <option key={item._id} value={item.subcategory}>
                                                    {item.subcategory}
                                                </option>
                                            ))}
                                        </select>
                                    ) : (
                                        <p className='text-red-400 font-roboto border-l-[8px] border-[#f25511] pl-[8px]'>This category has no subcategories. Please select another category.</p>
                                    )}
                                </div>
                            )}

                            {selectedSubCategory && (
                                <div className='category_select_from mt-[10px] rounded-b-[10px]'>
                                    <p className={`text-[12px] font-roboto ${selectedItem === "" ? "hidden" : "block"}`}>Select a subcategory type</p>
                                    {itemData.length > 0 ? (
                                        <select value={selectedItem} onChange={handleItemSelect}
                                            className='outline-none w-[100%] '>
                                            <option value="" disabled>Select a subcategory type</option>
                                            {itemData
                                                .filter(item => item.subcategory === selectedSubCategory)
                                                .map((item) => (
                                                    <option key={item._id} value={item.subcategoryitem}>
                                                        {item.subcategoryitem}
                                                    </option>
                                                ))}
                                        </select>
                                    ) : (
                                        <p className='text-red-400 font-roboto border-l-[8px] border-[#f25511] pl-[8px]'>This category has no subcategories. Please select another category.</p>
                                    )}
                                </div>
                            )}
                        </div>
                    )}
                </div>

                <div className={`w-[60%] ${selectedItem === "" ? "hidden" : "block"}`}>
                    {selectedItem.length > 0 ? (
                        <div>
                            <div className='category_select_from rounded-t-[12px]'>
                                <p className='text-black font-roboto font-semibold text-[14px] pb-[10px] border-b-[2px] border-[#f25511]'>Add Product Details</p>

                                <div className='product_details_input '>
                                    <div className='mt-[20px] flex flex-col gap-y-[10px]'>
                                        <div className='flex gap-[20px]'>
                                            <fieldset className='w-[50%] border-[1px] px-[10px] py-[3px] rounded-[5px] border-[#f25511] font-roboto text-[13px]'>
                                                <legend>Product Name :</legend>
                                                <input type="text" name="ProductName" className='outline-none w-[100%] text-[13px] font-roboto p-[5px]' value={selectedProductname} onChange={handleProductNameChange} />
                                            </fieldset>

                                            <fieldset className='w-[50%] border-[1px] px-[10px] py-[3px] rounded-[5px] border-[#f25511] font-roboto text-[13px]'>
                                                <legend>Short Description :</legend>
                                                <input type="text" name="ShortDescription" className='outline-none w-[100%] text-[13px] font-roboto p-[5px]' value={selectedShortDescription} onChange={handleselectedShortDescriptionChange} />
                                            </fieldset>
                                        </div>

                                        <div className='flex gap-[20px]'>
                                            <fieldset className='w-[50%] border-[1px] px-[10px] py-[3px] rounded-[5px] border-[#f25511] font-roboto text-[13px]'>
                                                <legend>Price :</legend>
                                                <input type="number" name="Price" className='outline-none w-[100%] text-[13px] font-roboto p-[5px]' value={selecteprice} onChange={handleselectepriceChange} />
                                            </fieldset>

                                            <fieldset className='w-[50%] border-[1px] px-[10px] py-[3px] rounded-[5px] border-[#f25511] font-roboto text-[13px]'>
                                                <legend>MRP :</legend>
                                                <input type="number" name="MRP" className='outline-none w-[100%] text-[13px] font-roboto p-[5px]' value={selectemrp} onChange={handleselectemrpChange} />
                                            </fieldset>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div className='category_select_from mt-[10px]'>
                                <div className={``}>
                                    <div>
                                        <h3>Select Color :</h3>
                                        <Select
                                            options={ProductColor}
                                            isMulti
                                            closeMenuOnSelect={false}
                                            hideSelectedOptions={false}
                                            components={{ Option: CustomOption }}
                                            onChange={handleChange}
                                            value={selectedColorOptions}
                                        />
                                    </div>

                                    <div className={`${selectedColorOptions.length === 0 ? "hidden" : "block"} bg-[#8080801c]  p-[10px] mt-[20px]  rounded-[7px]`}>
                                        <p className='text-[12px] font-roboto'>Upload Images</p>
                                        <Tabs>
                                            <TabList>
                                                {selectedColorOptions.map((option) => (
                                                    <Tab key={option.value}>{option.label}</Tab>
                                                ))}
                                            </TabList>

                                            {selectedColorOptions.map((option) => (
                                                <TabPanel key={option.value}>
                                                    <h2 className='text-[12px] font-roboto text-gray-400 mb-[10px] text-center'>{`Upload images and select size for ${option.label}`}</h2>
                                                    <div>
                                                        <input
                                                            type="file"
                                                            accept="image/*"
                                                            multiple
                                                            onChange={(e) => handleImageUpload(e, option.value)}
                                                        />
                                                    </div>
                                                    <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                                                        {imagePreviews[option.value] &&
                                                            imagePreviews[option.value].map((preview, index) => (
                                                                <div key={index} style={{ margin: '10px', position: 'relative' }}>
                                                                    <h3>Image {index + 1}</h3>
                                                                    <img src={preview.url} alt={`Preview ${index + 1}`} style={{ width: '100px', height: '100px' }} />
                                                                    <button
                                                                        onClick={() => handleCancelPreview(option.value, index)}
                                                                        style={{
                                                                            position: 'absolute',
                                                                            top: '10px',
                                                                            right: '5px',
                                                                        }}
                                                                        className='bg-bgmesho px-[5px] text-white rounded-[50px]'
                                                                    >
                                                                        <i className="fa fa-trash-o" aria-hidden="true"></i>
                                                                    </button>
                                                                </div>
                                                            ))}
                                                    </div>
                                                    <div className='mt-[10px]'>
                                                        <p className='text-[12px] font-roboto text-gray-400'>Select Sizes</p>
                                                        <div className='w-[100%] '>
                                                            <div>
                                                                <ReactSelect
                                                                    options={ProductSizeData}
                                                                    isMulti
                                                                    closeMenuOnSelect={false}
                                                                    hideSelectedOptions={false}
                                                                    components={{
                                                                        Option: CheckSelectSizeboxOption,
                                                                    }}
                                                                    onChange={(selected) => handleSelectSizeChange(selected, option.value)}
                                                                    value={selectedSizeOptions[option.value] || []}
                                                                    className='w-[100%] outline-none'
                                                                />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </TabPanel>
                                            ))}
                                        </Tabs>
                                    </div>

                                </div>
                            </div>

                            <div className='category_select_from mt-[10px]'>
                                <div className='flex flex-col gap-[20px]'>
                                    <div className='flex gap-[20px]'>
                                        <FNselectFiledOption
                                            name="fabric"
                                            data={productFabric}
                                            value={selectedFabric}
                                            onChange={handleFabricChange}
                                        />

                                        <FNselectFiledOption
                                            name="Sleeve Styling"
                                            data={productSleeveStyling}
                                            value={selectedSleeveStyling}
                                            onChange={selectedSleeveStylingChange}
                                        />
                                    </div>

                                    <div className='flex gap-[20px]'>
                                        <FNselectFiledOption
                                            name="Sleeve Length"
                                            data={productSleeveLength}
                                            value={selectedSleeveLength}
                                            onChange={handleSleeveLengthChange}
                                        />

                                        <FNselectFiledOption
                                            name="Fit/Shape"
                                            data={productFitShape}
                                            value={selectedfitshape}
                                            onChange={selectedfitshapeChange}
                                        />
                                    </div>

                                    <div className='flex gap-[20px]'>
                                        <FNselectFiledOption
                                            name="Neck"
                                            data={productNeck}
                                            value={selectedNeck}
                                            onChange={selectedNeckChange}
                                        />

                                        <FNselectFiledOption
                                            name="Occasion"
                                            data={productOccasion}
                                            value={selectedOccasion}
                                            onChange={selectedselectedOccasionChange}
                                        />
                                    </div>

                                    <div className='flex gap-[20px]'>
                                        <FNselectFiledOption
                                            name="Pattern"
                                            data={productPattern}
                                            value={selectedPattern}
                                            onChange={selectedPatternChange}
                                        />

                                        <FNselectFiledOption
                                            name="Print Or Pattern Type"
                                            data={productPrintOrPatterntype}
                                            value={selectedPrintOrPatternType}
                                            onChange={selectedPrintOrPatternTypeChange}
                                        />
                                    </div>

                                    <div className='flex gap-[20px]'>
                                        <fieldset className='w-[100%] border-[1px] px-[10px] py-[3px] rounded-[5px] border-[#f25511] font-roboto text-[13px]'>
                                            <legend>Description :</legend>
                                            <textarea className='outline-none w-[100%] text-[13px] font-roboto p-[5px]' value={selectdescription} onChange={handleselectdescriptionChange} ></textarea>
                                        </fieldset>
                                    </div>
                                </div>
                            </div>

                            <div className='category_select_from rounded-b-[12px] mt-[10px]'>
                                <button type='submit' className='login_owner_btn text-white' onClick={SubmitCatalog}>Submit Catalog</button>
                            </div>
                        </div>
                    ) : (
                        <div>
                            <p>Please select first all categories</p>
                        </div>
                    )}
                </div>
            </div>
            <ToastContainer />
        </div>

    );
};
