const AccessType = {
  NOACCESS: 0,
  FULLACCESS: 1,
  READONLY: 2,
  VALID: [0, 1, 2],
};

module.exports = {
  AccessType,
};
