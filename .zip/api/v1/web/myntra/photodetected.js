const { Router } = require("express");
const multer = require("multer");
const fs = require("fs");
const cloudinary = require("cloudinary").v2;
const { ImageAnnotatorClient } = require('@google-cloud/vision');

cloudinary.config({
  cloud_name: 'dtu4uys6g',
  api_key: '622592737848923',
  api_secret: 'WgZlFHw4-azYkG5xq-PSSd_2xdM',
});

const visionClient = new ImageAnnotatorClient({
  credentials: {
    client_email: 'manthan3319@vigilant-sol-429513-m2.iam.gserviceaccount.com',
    private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCaQ7ByeA3ctdmm\nlpAf5JmPFGc1SR93jmmCv72qPT5aotBykM1D/CK9aM0g4U/jOM0XtcXyoZAM5cn7\nGPsrnOcypzvbAUSH7GWom2dpyKWgToI7/Oo/SlXTfTI0Y5MEawd6taAS3amL3AtD\nlY3gra+L/rX3v9VNwFfWXHndpsF3NOBYbwntVU+sKs/tzoVbVlAKormq0ex1EEQV\nYJIIU1coDspwO1SMpTtq5V9AdfrYzYbfxkjwjzI3ygSmEuFE7PWxREi8f5kpDrE5\niX96JbdJZki3LUmYyXxPtm5Xdh/DSr8INg1S7m15bC3eTIXoStIygBsXAyfr37OG\n1GcxknBXAgMBAAECggEAHCvATScfYO7UkFduemSEplxTfKed13dqTTY2rKACgwq4\nhjNrSL8CmRRKYXbD3/q/eVT4kRZv9+r+t5wYQh6lGdrwU04n9ap15hR7DhZWKLAt\nmEbXgDdS9Qwn3ulQL75b30zLrqZMD/5fEDh/cEhHhok9McEWctxtLfg1SQTqz5nP\nsL7A8jzY+mKQZzEP2fKpcRer3OBfWM1f7I27SB8MgerSy58kIuBPFrIehwV2ADBo\nYzPI+pJ7WqNMWMrC6uYdeqmkeu0WeWDHHbR27FlPy1S1mqTef01VTG+bQFp3Zkye\n58U223JGj9BJAjO1in53DiQZ0eeTrHPLfRjG0p8EAQKBgQDRQltys3z6TIv5gq/m\n6D1Bh/5xX3cwo6MUNiSHLknmYrBUVB/DIgTS+TyrRmoWhuw39ux2IhCfPYKwvaNV\nT3Q09FWdyeJqBXE4E+U2AIoak6s2+CTSLRNqWcOboFwn2i9nWn77fJffJdA/XE41\n6JMffX71YYdjanLSqAU3KyzXaQKBgQC8uK05Fkx1DDUx7oK/EdikVXECuJyGkt2Z\naeTxvhgO3jI1+NCfEC22qyFnddqsEhXUpol6MzY7xDuKwD2rqqs54F+glSW12IIV\nPmDD+1BmiSR2CcLLhidBUu88eFkeOcp2C2cDcuQz7dDKhM00qFvxaSEl7DaDvCHB\ntPbN5hnRvwKBgDMJbCRdgm3JnZoNNbmrisUg1f3wurEyN+QGEIKn135JM5hdrCF7\nepG6GAHt+pHj9ljv8Fwfks5Dwkw49E0qQ71mmjsRshcJnMOAlrbFCunQekG9470f\nIU0e94ZNZiySGl2qxK2xhZj3MANEEA812iwj/4L5dnvYyoh2Uk9SSG2BAoGAGU/T\nu/JnstM+V0IcOzBTlEb5b1n/dHVCT49Ka7oJVAUtStvib1MmLnfpdQzzlVyfnPPx\nQHiZ7440Rjnei6XKbWrQqKMYebleSScip2aPtBD02PgaLl4B6dsLx1qE6W7q3sZM\nvMOuI+DjviXtuABUxJ5LGeECtsyG4oo5CAiysdUCgYBrJom3yRx63lCjX8XX81Np\nmDPtbWfCfPP/SQO2oXTgsQZikDNXA/ZS4YlpParh8ugn9ZAK7cqpWLTkOwNQ7Jws\n2RhycHp+VQO5Zi06X+nuNhfNlFyW1z4QweHz4wsoqYUP+feqwkZ+S1L4t+WPzBs+\nKIykZkaLeHlH0ePB6b1vBw==\n-----END PRIVATE KEY-----\n",
  },
});
const upload = multer({ dest: 'uploads/' });
const router = Router();

/**
 * @swagger
 * /api/v1/Myntra/photodetected:
 *   post:
 *     tags:
 *       - Myntra
 *     summary: Upload image and detect category (topwear/bottomwear) and dominant color.
 *     description: Uploads an image to Cloudinary, analyzes it using Google Cloud Vision API, and returns analysis results.
 *     consumes:
 *       - multipart/form-data
 *     parameters:
 *       - in: formData
 *         name: image
 *         type: file
 *         description: The image file to upload.
 *         required: true
 *     responses:
 *       '200':
 *         description: Successful upload and analysis.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 imageUrl:
 *                   type: string
 *                   description: The URL of the uploaded image in Cloudinary.
 *                 category:
 *                   type: string
 *                   description: The detected category of the image (topwear or bottomwear).
 *                 dominantColor:
 *                   type: string
 *                   description: The most dominant color detected in the image.
 *       '400':
 *         description: Bad request. No file uploaded.
 *       '500':
 *         description: Internal server error. Failed to process image.
 */
router.post(
  "/photodetected",
  upload.single('image'),
  async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }

      const filePath = req.file.path;

      const cloudinaryResult = await cloudinary.uploader.upload(filePath);
      const imageUrl = cloudinaryResult.secure_url;

      const [labelResult] = await visionClient.labelDetection(imageUrl);
      const labels = labelResult.labelAnnotations.map(label => label.description.toLowerCase());

      const [colorResult] = await visionClient.imageProperties(imageUrl);
      const colors = colorResult.imagePropertiesAnnotation.dominantColors.colors;

      let category = 'Uncategorized';

      if (labels.some(label => ['t-shirt', 'shirt'].includes(label))) {
        category = 'Topwear';
      } else if (labels.some(label => ['pants', 'jeans', 'trousers'].includes(label))) {
        category = 'Bottomwear';
      }

      let dominantColor = 'Unknown';

      if (colors && colors.length > 0) {
        const { color } = colors[0];
        dominantColor = `rgb(${color.red},${color.green},${color.blue})`;
      }

      fs.unlinkSync(filePath);

      res.status(200).json({
        imageUrl,
        category,
        dominantColor,
      });
    } catch (error) {
      console.error('Error processing image:', error);
      res.status(500).json({ error: 'Failed to process image' });
    }
  }
);

module.exports = router;
